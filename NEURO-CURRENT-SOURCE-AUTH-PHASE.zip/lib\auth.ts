﻿export type UserRole =
  | 'SUPER_ADMIN'
  | 'ADMIN'
  | 'CATALOG_MANAGER'
  | 'INVENTORY_MANAGER'
  | 'ORDER_MANAGER'
  | 'CUSTOMER_SUPPORT'
  | 'MARKETING_MANAGER'
  | 'FINANCE'
  | 'CUSTOMER'
  | 'DELIVERY_AGENT';

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  phone?: string | null;
  role: UserRole;
  status: 'ACTIVE' | 'INACTIVE';
};

export const STAFF_ROLES: UserRole[] = [
  'SUPER_ADMIN',
  'ADMIN',
  'CATALOG_MANAGER',
  'INVENTORY_MANAGER',
  'ORDER_MANAGER',
  'CUSTOMER_SUPPORT',
  'MARKETING_MANAGER',
  'FINANCE',
];

export function isStaffRole(role?: string | null){

  if(!role){
    return false;
  }

  return STAFF_ROLES.includes(
    role.toUpperCase() as UserRole
  );

}

export function saveAuth(
  accessToken:string,
  user:AuthUser,
  refreshToken?:string
){

  localStorage.setItem(
    'accessToken',
    accessToken
  );

  localStorage.setItem(
    'authUser',
    JSON.stringify(user)
  );

  if(refreshToken){

    localStorage.setItem(
      'refreshToken',
      refreshToken
    );

  }

}


export function updateAccessToken(
  accessToken:string
){

  localStorage.setItem(
    'accessToken',
    accessToken
  );

}


export function getRefreshToken(){

  if(typeof window === 'undefined'){
    return null;
  }

  return localStorage.getItem(
    'refreshToken'
  );

}


export function clearAuth(){

  localStorage.removeItem(
    'accessToken'
  );

  localStorage.removeItem(
    'refreshToken'
  );

  localStorage.removeItem(
    'authUser'
  );

}


export function getStoredUser():AuthUser|null{

  if(typeof window === 'undefined'){
    return null;
  }

  const raw =
    localStorage.getItem('authUser');


  if(!raw){
    return null;
  }


  try{

    return JSON.parse(raw);

  }
  catch{

    clearAuth();

    return null;

  }

}
