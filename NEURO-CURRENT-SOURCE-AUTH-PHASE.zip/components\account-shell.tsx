'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Bell, Heart, MapPin, Package, RotateCcw, UserRound
} from 'lucide-react';

const links = [
  {href:'/account',label:'Overview',icon:UserRound},
  {href:'/account/addresses',label:'Addresses',icon:MapPin},
  {href:'/account/wishlist',label:'Wishlist',icon:Heart},
  {href:'/account/notifications',label:'Notifications',icon:Bell},
  {href:'/account/returns',label:'Returns',icon:RotateCcw},
  {href:'/account/payments',label:'Payments',icon:Package},
  {href:'/account/profile',label:'Profile',icon:UserRound},
  {href:'/account/security',label:'Security',icon:UserRound},
];

export default function AccountShell({children}:{children:React.ReactNode}){
  const pathname=usePathname();
  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-5 py-8 lg:grid-cols-[230px_1fr]">
      <aside className="h-fit rounded-[1.5rem] border border-slate-200 bg-white p-3 lg:sticky lg:top-28">
        <div className="mb-3 rounded-2xl bg-[#1464f4] p-4 text-white">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-white/10"><Package size={18}/></span>
            <div><p className="text-sm font-black">My account</p><p className="text-[11px] text-white/45">Orders & preferences</p></div>
          </div>
        </div>
        <nav className="grid grid-cols-2 gap-2 sm:grid-cols-5 lg:grid-cols-1">
          {links.map(({href,label,icon:Icon})=>{
            const active=pathname===href;
            return <Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-black transition ${active?'bg-[#1464f4] text-white':'text-slate-600 hover:bg-slate-50 hover:text-slate-950'}`}>
              <Icon size={16}/><span>{label}</span>
            </Link>
          })}
        </nav>
      </aside>
      <div className="min-w-0">{children}</div>
    </div>
  )
}



