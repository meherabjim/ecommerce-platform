'use client';

import { useEffect,useMemo,useState } from 'react';
import Link from 'next/link';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import Navbar from '@/components/navbar';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { localizedCategoryName, localizedProductDescription, localizedProductName } from '@/lib/localized';

export default function ShopPage(){
  const {language}=useI18n();
  const [products,setProducts]=useState<any[]>([]);
  const [categories,setCategories]=useState<any[]>([]);
  const [query,setQuery]=useState('');
  const [categoryId,setCategoryId]=useState('');
  const [sort,setSort]=useState('featured');
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    const params=new URLSearchParams(window.location.search);
    setQuery(params.get('q')||'');setCategoryId(params.get('category')||'');
    if(params.get('sort')==='new')setSort('new');if(params.get('offers')==='1')setSort('offers');
    Promise.all([api.get('/catalog/public/products'),api.get('/catalog/public/categories')]).then(([p,c])=>{setProducts(p.data||[]);setCategories(c.data||[])}).finally(()=>setLoading(false));
  },[]);

  const filtered=useMemo(()=>{
    const list=products.filter((p:any)=>{
      const q=query.trim().toLowerCase();
      const search=!q||[p.name,p.nameBn,p.shortDescription,p.shortDescriptionBn,p.description,p.descriptionBn,p.brand?.name,p.category?.name,p.category?.nameBn].filter(Boolean).join(' ').toLowerCase().includes(q);
      return search&&(!categoryId||p.categoryId===categoryId);
    });
    return [...list].sort((a:any,b:any)=>{
      const av=Number(a.variants?.[0]?.salePrice||a.variants?.[0]?.price||0),bv=Number(b.variants?.[0]?.salePrice||b.variants?.[0]?.price||0);
      if(sort==='price-low')return av-bv;if(sort==='price-high')return bv-av;
      if(sort==='name')return localizedProductName(language,a).localeCompare(localizedProductName(language,b),language==='bn'?'bn':'en');
      if(sort==='featured')return Number(Boolean(b.featured))-Number(Boolean(a.featured));
      if(sort==='new')return new Date(b.createdAt||0).getTime()-new Date(a.createdAt||0).getTime();
      if(sort==='offers')return Number(Boolean(b.variants?.[0]?.salePrice))-Number(Boolean(a.variants?.[0]?.salePrice));return 0;
    });
  },[products,query,categoryId,sort,language]);

  return <main className="min-h-screen bg-[#f7f9fc] text-slate-950"><Navbar/>
    <section className="border-b border-slate-200 bg-white"><div className="mx-auto max-w-7xl px-5 py-10"><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">{language==='bn'?'পণ্যের ক্যাটালগ':'Product catalog'}</p><div className="mt-2 flex flex-col justify-between gap-4 lg:flex-row lg:items-end"><div><h1 className="text-4xl font-black tracking-tight sm:text-5xl">{language==='bn'?'আপনার পরবর্তী পছন্দের পণ্য খুঁজুন।':'Find your next favorite.'}</h1><p className="mt-3 max-w-2xl text-slate-500">{language==='bn'?'লাইভ পণ্য ও উপলভ্য ভ্যারিয়েন্ট খুঁজুন, ফিল্টার করুন এবং তুলনা করুন।':'Search, filter and compare live products and available variants.'}</p></div><p className="text-sm font-bold text-slate-500">{filtered.length} {language==='bn'?'টি পণ্য':'products'}</p></div></div></section>

    <section className="mx-auto max-w-7xl px-5 py-8">
      <div className="premium-card sticky top-[116px] z-30 rounded-2xl p-3"><div className="grid gap-3 lg:grid-cols-[1fr_220px_220px_auto]">
        <label className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4"><Search size={17} className="text-slate-400"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder={language==='bn'?'পণ্য, ব্র্যান্ড বা ক্যাটাগরি খুঁজুন...':'Search name, brand or category...'} className="focus-ring w-full bg-transparent py-3 text-sm outline-none"/>{query&&<button onClick={()=>setQuery('')}><X size={16}/></button>}</label>
        <select value={categoryId} onChange={e=>setCategoryId(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold"><option value="">{language==='bn'?'সব ক্যাটাগরি':'All categories'}</option>{categories.map((c:any)=><option key={c.id} value={c.id}>{localizedCategoryName(language,c)}</option>)}</select>
        <select value={sort} onChange={e=>setSort(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold"><option value="featured">{language==='bn'?'ফিচার্ড আগে':'Featured first'}</option><option value="price-low">{language==='bn'?'দাম: কম থেকে বেশি':'Price: low to high'}</option><option value="price-high">{language==='bn'?'দাম: বেশি থেকে কম':'Price: high to low'}</option><option value="name">{language==='bn'?'নাম':'Name'}</option><option value="new">{language==='bn'?'নতুন আগে':'Newest'}</option><option value="offers">{language==='bn'?'অফার আগে':'Offers first'}</option></select>
        <button onClick={()=>{setQuery('');setCategoryId('');setSort('featured')}} className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-black"><SlidersHorizontal size={16}/>{language==='bn'?'রিসেট':'Reset'}</button>
      </div></div>

      {loading?<div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">{Array.from({length:8}).map((_,i)=><div key={i} className="h-96 animate-pulse rounded-3xl bg-slate-200/60"/>)}</div>:<div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">{filtered.map((p:any)=>{const v=p.variants?.[0];const galleryImage=Array.isArray(p.media)?p.media.find((m:any)=>m.type==='image')?.url:null;const image=v?.imageUrl||galleryImage||p.primaryImageUrl;const price=v?Number(v.salePrice||v.price):null;const regular=v?Number(v.price):null;const name=localizedProductName(language,p);const desc=localizedProductDescription(language,p,true)||localizedProductDescription(language,p,false)||(language==='bn'?'পণ্যের বিস্তারিত ও ভ্যারিয়েন্ট দেখুন।':'View product details and variants.');return <Link key={p.id} href={`/shop/${p.slug}`} className="group overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-xl"><div className="relative overflow-hidden bg-slate-100">{image?<img src={image} alt={name} className="aspect-[4/3] w-full object-cover transition duration-500 group-hover:scale-[1.04]"/>:<div className="grid aspect-[4/3] place-items-center bg-gradient-to-br from-blue-50 to-slate-100 text-6xl font-black text-blue-200">{name?.[0]}</div>}<div className="absolute left-3 top-3 flex gap-2">{p.featured&&<span className="rounded-full bg-[#1464f4] px-3 py-1 text-[10px] font-black uppercase tracking-wider text-white">{language==='bn'?'ফিচার্ড':'Featured'}</span>}{v?.stock<=0&&<span className="rounded-full bg-white px-3 py-1 text-[10px] font-black uppercase tracking-wider text-rose-600">{language==='bn'?'স্টক শেষ':'Sold out'}</span>}</div></div><div className="p-5"><p className="text-[10px] font-black uppercase tracking-[.16em] text-slate-400">{p.category?localizedCategoryName(language,p.category):(language==='bn'?'পণ্য':'Product')}{p.brand?.name?` · ${p.brand.name}`:''}</p><h2 className="mt-2 line-clamp-1 text-lg font-black">{name}</h2><p className="mt-2 line-clamp-2 min-h-10 text-sm leading-5 text-slate-500">{desc}</p><div className="mt-5 flex items-end justify-between gap-3"><div>{price!==null?<><p className="text-xl font-black">{language==='bn'?'৳':'BDT '}{price}</p>{regular!==null&&regular>price&&<p className="text-xs text-slate-400 line-through">{language==='bn'?'৳':'BDT '}{regular}</p>}</>:<p className="font-black">{language==='bn'?'অপশন দেখুন':'View options'}</p>}</div><p className="text-xs font-bold text-slate-400">{v?`${v.stock??0} ${language==='bn'?'টি স্টকে':'in stock'}`:''}</p></div></div></Link>})}</div>}
      {!loading&&filtered.length===0&&<div className="mt-10 rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center"><p className="text-lg font-black">{language==='bn'?'কোনো পণ্য পাওয়া যায়নি':'No products found'}</p><p className="mt-2 text-sm text-slate-500">{language==='bn'?'অন্য কিছু খুঁজুন অথবা ফিল্টার পরিষ্কার করুন।':'Try another search or clear the filters.'}</p></div>}
    </section><StoreFooter/></main>
}
