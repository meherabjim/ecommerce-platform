'use client';

import { FormEvent,useMemo,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowLeft, Check, ShieldCheck, UserPlus } from 'lucide-react';
import { api } from '@/lib/api';
import { saveAuth } from '@/lib/auth';

export default function RegisterPage(){
  const router=useRouter();
  const [form,setForm]=useState({name:'',email:'',phone:'',password:''});
  const [error,setError]=useState('');
  const [loading,setLoading]=useState(false);

  const checks=useMemo(()=>[
    ['8+ characters',form.password.length>=8],
    ['Uppercase',/[A-Z]/.test(form.password)],
    ['Lowercase',/[a-z]/.test(form.password)],
    ['Number',/\d/.test(form.password)],
  ] as [string,boolean][],[form.password]);

  async function submit(e:FormEvent){
    e.preventDefault();setError('');setLoading(true);
    try{
      const {data}=await api.post('/auth/register',{...form,phone:form.phone||undefined});
      saveAuth(data.accessToken,data.user,data.refreshToken);router.push('/account');
    }catch(err:any){const m=err?.response?.data?.message;setError(Array.isArray(m)?m.join(', '):m||'Registration failed.')}
    finally{setLoading(false)}
  }

  return (
    <main className="min-h-screen bg-[#f6f7f9]">
      <div className="mx-auto grid min-h-screen max-w-7xl items-center gap-10 px-5 py-10 lg:grid-cols-[.85fr_1.15fr]">
        <section>
          <Link href="/" className="inline-flex items-center gap-2 text-sm font-black text-slate-600"><ArrowLeft size={16}/>Back to store</Link>
          <p className="mt-10 text-xs font-black uppercase tracking-[.2em] text-slate-400">Customer account</p>
          <h1 className="mt-3 max-w-xl text-5xl font-black leading-[1.03] tracking-[-.04em]">Your shopping life, organized.</h1>
          <p className="mt-5 max-w-lg text-base leading-7 text-slate-500">Create an account to save addresses, keep a wishlist, track deliveries, review purchases and request returns.</p>
          <div className="mt-8 grid gap-3 sm:grid-cols-2">
            {['Saved delivery addresses','Wishlist & notifications','Order tracking','Returns & reviews'].map(x=><div key={x} className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white p-4"><span className="grid h-8 w-8 place-items-center rounded-full bg-emerald-50 text-emerald-700"><Check size={15}/></span><span className="text-sm font-black">{x}</span></div>)}
          </div>
        </section>

        <form onSubmit={submit} className="rounded-[2rem] border border-slate-200 bg-white p-7 premium-shadow sm:p-9">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#1464f4] text-white"><UserPlus size={20}/></div>
          <h2 className="mt-6 text-3xl font-black">Create your account</h2>
          <p className="mt-2 text-sm text-slate-500">It takes less than a minute.</p>
          {error&&<div className="mt-5 rounded-xl bg-rose-50 p-3 text-sm font-semibold text-rose-700">{error}</div>}

          <div className="mt-6 grid gap-4 sm:grid-cols-2">
            <label className="text-sm font-black sm:col-span-2">Full name
              <input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3.5 font-normal outline-none"/>
            </label>
            <label className="text-sm font-black sm:col-span-2">Email
              <input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3.5 font-normal outline-none"/>
            </label>
            <label className="text-sm font-black">Phone <span className="font-normal text-slate-400">(optional)</span>
              <input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3.5 font-normal outline-none"/>
            </label>
            <label className="text-sm font-black">Password
              <input required type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3.5 font-normal outline-none"/>
            </label>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">{checks.map(([x,ok])=><span key={x} className={`rounded-full px-3 py-1.5 text-[10px] font-black ${ok?'bg-emerald-50 text-emerald-700':'bg-slate-100 text-slate-400'}`}>{x}</span>)}</div>
          <button disabled={loading} className="mt-7 w-full rounded-xl bg-[#1464f4] py-3.5 font-black text-white disabled:opacity-50">{loading?'Creating account...':'Create account'}</button>
          <div className="mt-5 flex gap-3 rounded-2xl bg-slate-50 p-4"><ShieldCheck size={18} className="shrink-0"/><p className="text-xs leading-5 text-slate-500">Use a unique password. Account access protects your addresses, order history and delivery information.</p></div>
          <p className="mt-6 text-center text-sm text-slate-500">Already registered? <Link href="/login" className="font-black text-slate-950">Sign in</Link></p>
        </form>
      </div>
    </main>
  )
}

