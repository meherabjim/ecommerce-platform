'use client';

import { useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import { RotateCcw } from 'lucide-react';
import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const pretty=(x:string)=>String(x||'').replaceAll('_',' ');

export default function ReturnsPage(){
  const router=useRouter();const [items,setItems]=useState<any[]>([]);
  useEffect(()=>{if(!getStoredUser()){router.replace('/login');return}api.get('/returns').then(r=>setItems(r.data||[]))},[router]);
  return <main className="min-h-screen text-slate-950"><Navbar/><AccountShell>
    <div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">After-sales service</p><h1 className="mt-2 text-4xl font-black">Returns & refunds</h1><p className="mt-2 text-sm text-slate-500">Request returns from delivered order pages and track progress here.</p></div>
    <div className="mt-6 space-y-3">{items.map(x=><article key={x.id} className="premium-card rounded-2xl p-5">
      <div className="flex flex-wrap justify-between gap-4"><div className="flex gap-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1464f4] text-white"><RotateCcw size={18}/></span><div><p className="font-black">Return request</p><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">{x.reason}</p></div></div><span className="h-fit rounded-full bg-slate-100 px-3 py-2 text-[10px] font-black uppercase">{pretty(x.status)}</span></div>
      {x.adminNote&&<p className="mt-4 rounded-xl bg-slate-50 p-4 text-sm"><b>Update:</b> {x.adminNote}</p>}
    </article>)}</div>
    {!items.length&&<div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center"><RotateCcw className="mx-auto text-slate-300"/><p className="mt-4 font-black">No return requests</p><p className="mt-2 text-sm text-slate-500">Eligible delivered orders can be returned from the order detail page.</p></div>}
  </AccountShell><StoreFooter/></main>
}
