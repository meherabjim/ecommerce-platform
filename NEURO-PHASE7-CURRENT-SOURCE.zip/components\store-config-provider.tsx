'use client';

import {
  createContext, useContext, useEffect, useMemo, useState,
} from 'react';
import { api } from '@/lib/api';

type StoreConfig = Record<string,any>;

const StoreConfigContext=createContext<StoreConfig>({});

export function StoreConfigProvider({children}:{children:React.ReactNode}){
  const [config,setConfig]=useState<StoreConfig>({});

  useEffect(()=>{
    api.get('/cms/public/settings').then(r=>{
      const value=r.data||{};
      setConfig(value);

      const theme=value['store.theme']||{};
      const root=document.documentElement;
      if(theme.primary) root.style.setProperty('--store-primary',theme.primary);
      if(theme.surface) root.style.setProperty('--store-surface',theme.surface);
      if(theme.background) root.style.setProperty('--store-background',theme.background);
      if(theme.accent) root.style.setProperty('--store-accent',theme.accent);
      if(theme.radius) root.style.setProperty('--store-radius',theme.radius);
      if(theme.fontFamily) root.style.fontFamily=theme.fontFamily;
    }).catch(()=>{});
  },[]);

  const memo=useMemo(()=>config,[config]);
  return <StoreConfigContext.Provider value={memo}>{children}</StoreConfigContext.Provider>
}

export function useStoreConfig(){return useContext(StoreConfigContext)}
