export default function Loading() {
  return (
    <main className="grid min-h-[55vh] place-items-center bg-[#f5f6f8]">
      <div className="text-center">
        <span className="mx-auto block h-10 w-10 animate-spin rounded-full border-4 border-slate-200 border-t-slate-950" />
        <p className="mt-4 text-sm font-black text-slate-500">Loading Neuro Commerce...</p>
      </div>
    </main>
  );
}
