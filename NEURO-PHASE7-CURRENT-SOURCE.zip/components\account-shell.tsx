'use client';
import Link from 'next/link';
import { usePathname,useRouter } from 'next/navigation';
import { useEffect,useState } from 'react';
import { Bell,Heart,MapPin,Package,RotateCcw,UserRound,LogOut,ShieldCheck,WalletCards } from 'lucide-react';
import { clearAuth,getStoredUser } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
const links=[['/account','Overview','ওভারভিউ',UserRound],['/account/addresses','Addresses','ঠিকানা',MapPin],['/account/wishlist','Wishlist','পছন্দের তালিকা',Heart],['/account/notifications','Notifications','নোটিফিকেশন',Bell],['/account/returns','Returns','রিটার্ন',RotateCcw],['/account/payments','Payments','পেমেন্ট',WalletCards],['/account/profile','Profile','প্রোফাইল',UserRound],['/account/security','Security','নিরাপত্তা',ShieldCheck]] as const;
export default function AccountShell({children}:{children:React.ReactNode}){
 const pathname=usePathname(); const router=useRouter(); const {language}=useI18n(); const [user,setUser]=useState<any>(null);
 useEffect(()=>{const u=getStoredUser(); if(!u){router.replace(`/login?next=${encodeURIComponent(pathname)}`);return} if(u.role!=='CUSTOMER'){router.replace(u.role==='DELIVERY_AGENT'?'/delivery':'/admin');return} setUser(u)},[pathname,router]);
 function logout(){clearAuth();router.replace('/login');router.refresh()}
 return <div className="mx-auto grid max-w-7xl gap-6 px-5 py-8 lg:grid-cols-[250px_1fr]"><aside className="h-fit rounded-[1.5rem] border border-slate-200 bg-white p-3 lg:sticky lg:top-28"><div className="mb-3 rounded-2xl bg-[#1464f4] p-4 text-white"><div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-white/15"><Package size={18}/></span><div className="min-w-0"><p className="truncate text-sm font-black">{user?.name||(language==='bn'?'আমার অ্যাকাউন্ট':'My account')}</p><p className="truncate text-[11px] text-white/70">{user?.email||(language==='bn'?'অর্ডার ও পছন্দ':'Orders & preferences')}</p></div></div></div><nav className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-1">{links.map(([href,en,bn,Icon])=><Link key={href} href={href} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-black transition ${pathname===href?'bg-[#1464f4] text-white':'text-slate-600 hover:bg-blue-50 hover:text-blue-700'}`}><Icon size={16}/><span>{language==='bn'?bn:en}</span></Link>)}</nav><button onClick={logout} className="mt-3 flex w-full items-center gap-3 rounded-xl border border-rose-100 bg-rose-50 px-3 py-3 text-sm font-black text-rose-600 hover:bg-rose-100"><LogOut size={16}/>{language==='bn'?'লগআউট':'Sign out'}</button></aside><div className="min-w-0">{children}</div></div>
}
