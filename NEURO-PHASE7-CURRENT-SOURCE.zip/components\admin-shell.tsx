'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  BarChart3,
  Boxes,
  ChevronRight,
  ClipboardList,
  FileBarChart,
  Gift,
  LayoutDashboard,
  LogOut,
  Menu,
  PackageCheck,
  PackageSearch,
  PlugZap,
  RotateCcw,
  Settings2,
  ShieldCheck,
  Star,
  Truck,
  UsersRound,
  Warehouse,
  WalletCards,
  X,
  Bell,
} from 'lucide-react';

import { clearAuth, getStoredUser, isStaffRole, canAccessAdminPath } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';

const ALL = ['SUPER_ADMIN', 'ADMIN'];

type NavItem = {
  href: string;
  label: string;
  labelBn: string;
  icon: React.ComponentType<{ size?: number }>;
  roles: string[];
};

const links: NavItem[] = [
  { href: '/admin', label: 'Overview', labelBn: 'ওভারভিউ', icon: LayoutDashboard, roles: [...ALL, 'CATALOG_MANAGER', 'INVENTORY_MANAGER', 'ORDER_MANAGER', 'CUSTOMER_SUPPORT', 'MARKETING_MANAGER', 'FINANCE'] },
  { href: '/admin/catalog', label: 'Catalog', labelBn: 'ক্যাটালগ', icon: Boxes, roles: [...ALL, 'CATALOG_MANAGER'] },
  { href: '/admin/barcodes', label: 'Barcodes', labelBn: 'বারকোড', icon: PackageSearch, roles: [...ALL, 'CATALOG_MANAGER', 'INVENTORY_MANAGER'] },
  { href: '/admin/inventory', label: 'Inventory', labelBn: 'ইনভেন্টরি', icon: Warehouse, roles: [...ALL, 'INVENTORY_MANAGER'] },
  { href: '/admin/orders', label: 'Orders', labelBn: 'অর্ডার', icon: ClipboardList, roles: [...ALL, 'ORDER_MANAGER', 'CUSTOMER_SUPPORT', 'FINANCE'] },
  { href: '/admin/shipments', label: 'Shipments', labelBn: 'শিপমেন্ট', icon: PackageCheck, roles: [...ALL, 'ORDER_MANAGER'] },
  { href: '/admin/delivery', label: 'Delivery', labelBn: 'ডেলিভারি', icon: Truck, roles: [...ALL, 'ORDER_MANAGER'] },
  { href: '/admin/shipping', label: 'Shipping', labelBn: 'শিপিং', icon: Settings2, roles: [...ALL, 'ORDER_MANAGER'] },
  { href: '/admin/customers', label: 'Customers', labelBn: 'ক্রেতা', icon: UsersRound, roles: [...ALL, 'CUSTOMER_SUPPORT'] },
  { href: '/admin/users', label: 'Staff & Users', labelBn: 'স্টাফ ও ইউজার', icon: UsersRound, roles: [...ALL] },
  { href: '/admin/promotions', label: 'Promotions', labelBn: 'প্রমোশন', icon: Gift, roles: [...ALL, 'MARKETING_MANAGER'] },
  { href: '/admin/reviews', label: 'Reviews', labelBn: 'রিভিউ', icon: Star, roles: [...ALL, 'MARKETING_MANAGER', 'CUSTOMER_SUPPORT'] },
  { href: '/admin/returns', label: 'Returns', labelBn: 'রিটার্ন', icon: RotateCcw, roles: [...ALL, 'ORDER_MANAGER', 'CUSTOMER_SUPPORT'] },
  { href: '/admin/notifications', label: 'Notifications', labelBn: 'নোটিফিকেশন', icon: Bell, roles: [...ALL, 'CUSTOMER_SUPPORT', 'MARKETING_MANAGER'] },
  { href: '/admin/finance', label: 'Finance', labelBn: 'ফাইন্যান্স', icon: WalletCards, roles: [...ALL, 'FINANCE'] },
  { href: '/admin/reports', label: 'Reports', labelBn: 'রিপোর্ট', icon: FileBarChart, roles: [...ALL, 'INVENTORY_MANAGER', 'ORDER_MANAGER', 'MARKETING_MANAGER', 'FINANCE'] },
  { href: '/admin/integrations', label: 'Integrations', labelBn: 'ইন্টিগ্রেশন', icon: PlugZap, roles: [...ALL] },
  { href: '/admin/cms', label: 'CMS & Theme', labelBn: 'সিএমএস ও থিম', icon: BarChart3, roles: [...ALL, 'MARKETING_MANAGER'] },
  { href: '/admin/security', label: 'Security', labelBn: 'নিরাপত্তা', icon: ShieldCheck, roles: [...ALL] },
  { href: '/admin/settings', label: 'Store Settings', labelBn: 'স্টোর সেটিংস', icon: Settings2, roles: [...ALL] },
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { language } = useI18n();
  const [open, setOpen] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const stored = getStoredUser();
    if (!stored) {
      router.replace('/login');
      return;
    }
    if (!isStaffRole(stored.role)) {
      router.replace('/account');
      return;
    }
    setUser(stored);
  }, [router]);

  const role = String(user?.role || '').toUpperCase();
  const visible = useMemo(() => links.filter((item) => item.roles.includes(role)), [role]);

  function logout() {
    clearAuth();
    setOpen(false);
    router.replace('/login');
    router.refresh();
  }

  const denied = mounted && user && !canAccessAdminPath(user.role, pathname);
  const label = (item: NavItem) => (language === 'bn' ? item.labelBn : item.label);

  const menu = (
    <div className="flex h-full min-h-0 flex-col">
      <div className="shrink-0 border-b border-slate-200 pb-5">
        <Link href="/admin" onClick={() => setOpen(false)} className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#1464f4] text-lg font-black text-white shadow-sm">N</span>
          <div className="min-w-0">
            <p className="truncate font-black text-slate-900">Neuro Commerce</p>
            <p className="mt-1 text-[10px] font-bold uppercase tracking-[.18em] text-blue-600">
              {language === 'bn' ? 'অ্যাডমিন কনসোল' : 'Admin console'}
            </p>
          </div>
        </Link>

        <div className="mt-5 rounded-2xl border border-blue-100 bg-blue-50 p-4">
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-blue-600 shadow-sm">
              <ShieldCheck size={17} />
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-black text-slate-900">
                {mounted ? user?.name || 'Administrator' : 'Administrator'}
              </p>
              <p className="truncate text-[10px] font-bold uppercase tracking-wide text-slate-500">
                {mounted ? (role || 'STAFF').replaceAll('_', ' ') : 'STAFF'}
              </p>
            </div>
          </div>
        </div>
      </div>

      <nav className="mt-4 min-h-0 flex-1 space-y-1 overflow-y-auto pr-1">
        {visible.map((item) => {
          const Icon = item.icon;
          const active = item.href === '/admin' ? pathname === '/admin' : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className={`group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-black transition ${
                active
                  ? 'bg-[#1464f4] text-white shadow-sm'
                  : 'text-slate-600 hover:bg-blue-50 hover:text-blue-700'
              }`}
            >
              <Icon size={17} />
              <span className="flex-1">{label(item)}</span>
              {active && <ChevronRight size={15} />}
            </Link>
          );
        })}
      </nav>

      <div className="shrink-0 border-t border-slate-200 pt-4">
        <button
          onClick={logout}
          className="flex w-full items-center gap-3 rounded-xl border border-rose-100 bg-rose-50 px-3 py-3 text-sm font-black text-rose-600 transition hover:bg-rose-100"
        >
          <LogOut size={17} />
          {language === 'bn' ? 'লগআউট' : 'Sign out'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f6f8fb] text-slate-950">
      <aside className="fixed inset-y-0 left-0 z-50 hidden h-screen w-[286px] border-r border-slate-200 bg-white p-5 shadow-sm lg:block">
        {menu}
      </aside>

      <header className="sticky top-0 z-40 flex h-16 items-center justify-between border-b border-slate-200 bg-white/95 px-4 backdrop-blur-xl lg:hidden">
        <Link href="/admin" className="flex items-center gap-3 font-black text-slate-900">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#1464f4] text-white">N</span>
          <span>{language === 'bn' ? 'অ্যাডমিন' : 'Admin'}</span>
        </Link>
        <button onClick={() => setOpen(true)} className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700">
          <Menu size={19} />
        </button>
      </header>

      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <button aria-label="Close menu" onClick={() => setOpen(false)} className="absolute inset-0 bg-slate-900/35 backdrop-blur-sm" />
          <aside className="absolute inset-y-0 left-0 h-screen w-[88%] max-w-[310px] bg-white p-5 shadow-2xl">
            <div className="mb-3 flex justify-end">
              <button onClick={() => setOpen(false)} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700">
                <X size={18} />
              </button>
            </div>
            <div className="h-[calc(100%-52px)]">{menu}</div>
          </aside>
        </div>
      )}

      <main className="lg:pl-[286px]">
        <div className="mx-auto max-w-[1580px] p-4 sm:p-5 md:p-8 xl:p-10">{denied ? <div className="rounded-3xl border border-amber-200 bg-amber-50 p-8"><ShieldCheck className="text-amber-600"/><h1 className="mt-4 text-2xl font-black">{language==='bn'?'এই পেজে আপনার অনুমতি নেই':'Access denied'}</h1><p className="mt-2 text-sm text-slate-600">{language==='bn'?'আপনি লগইন অবস্থাতেই আছেন। আপনার রোলে শুধু এই পেজের অনুমতি নেই।':'You are still signed in. Your role does not have permission for this page.'}</p><Link href="/admin" className="mt-5 inline-flex rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-black text-white">{language==='bn'?'ড্যাশবোর্ডে ফিরুন':'Back to dashboard'}</Link></div> : children}</div>
      </main>
    </div>
  );
}
