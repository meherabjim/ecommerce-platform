'use client';

import { FormEvent,useEffect,useMemo,useState } from 'react';
import { useRouter } from 'next/navigation';
import { Banknote, CreditCard, RefreshCcw, Search, WalletCards } from 'lucide-react';
import AdminShell from '@/components/admin-shell';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const money=(v:any)=>`BDT ${Number(v||0).toLocaleString(undefined,{maximumFractionDigits:2})}`;
const pretty=(v:string)=>String(v||'').replaceAll('_',' ');

export default function FinancePage(){
  const router=useRouter();
  const [transactions,setTransactions]=useState<any[]>([]);
  const [refunds,setRefunds]=useState<any[]>([]);
  const [orders,setOrders]=useState<any[]>([]);
  const [message,setMessage]=useState('');
  const [query,setQuery]=useState('');
  const [form,setForm]=useState({orderId:'',amount:'',paymentMethod:'CASH',externalReference:''});
  const [refund,setRefund]=useState({orderId:'',amount:'',reason:''});

  async function load(){
    const [t,r,o]=await Promise.all([
      api.get('/payments/admin/transactions'),
      api.get('/payments/admin/refunds'),
      api.get('/admin/orders'),
    ]);
    setTransactions(t.data||[]);setRefunds(r.data||[]);setOrders(o.data||[]);
  }
  useEffect(()=>{const u=getStoredUser();if(!u||!['SUPER_ADMIN','ADMIN','FINANCE'].includes(String(u.role).toUpperCase())){router.replace('/admin?denied=1');return}load()},[router]);

  async function collect(e:FormEvent){
    e.preventDefault();setMessage('');
    try{
      await api.post('/payments/admin/manual',{
        orderId:form.orderId,
        amount:Number(form.amount),
        paymentMethod:form.paymentMethod,
        externalReference:form.externalReference||undefined,
        provider:'MANUAL',
        type:'DUE_COLLECTION',
        idempotencyKey:`manual-${form.orderId}-${Date.now()}`,
      });
      setMessage('Payment recorded and order balance recalculated.');
      setForm({orderId:'',amount:'',paymentMethod:'CASH',externalReference:''});await load();
    }catch(e:any){setMessage(e?.response?.data?.message||'Payment failed.')}
  }

  async function createRefund(e:FormEvent){
    e.preventDefault();setMessage('');
    try{
      await api.post('/payments/admin/refunds',{orderId:refund.orderId,amount:Number(refund.amount),reason:refund.reason});
      setRefund({orderId:'',amount:'',reason:''});setMessage('Refund request created.');await load();
    }catch(e:any){setMessage(e?.response?.data?.message||'Refund creation failed.')}
  }

  async function refundStatus(id:string,status:string){
    await api.patch(`/payments/admin/refunds/${id}`,{status});
    await load();
  }

  const visible=useMemo(()=>transactions.filter(x=>`${x.orderId} ${x.provider} ${x.externalReference||''} ${x.status}`.toLowerCase().includes(query.toLowerCase())),[transactions,query]);
  const verified=transactions.filter(x=>x.status==='VERIFIED').reduce((s,x)=>s+Number(x.amount||0),0);
  const pending=transactions.filter(x=>x.status==='PENDING').reduce((s,x)=>s+Number(x.amount||0),0);
  const completedRefunds=refunds.filter(x=>x.status==='COMPLETED').reduce((s,x)=>s+Number(x.amount||0),0);

  return <AdminShell>
    <div className="flex flex-col justify-between gap-4 xl:flex-row xl:items-end"><div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">SRS finance operations</p><h1 className="mt-2 text-4xl font-black tracking-tight">Payments & refunds</h1><p className="mt-2 text-sm text-slate-500">Ledger, due collection, manual payment verification and refund processing.</p></div><label className="flex items-center gap-2 rounded-xl border bg-white px-4"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search transaction..." className="py-3 outline-none"/></label></div>

    <section className="mt-6 grid gap-3 sm:grid-cols-3">{[[WalletCards,'Verified payments',money(verified)],[CreditCard,'Pending intents',money(pending)],[RefreshCcw,'Completed refunds',money(completedRefunds)]].map(([Icon,l,v]:any)=><div key={l} className="rounded-2xl border border-slate-200 bg-white p-5"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#1464f4] text-white"><Icon size={17}/></span><p className="mt-4 text-2xl font-black">{v}</p><p className="text-sm text-slate-500">{l}</p></div>)}</section>
    {message&&<p className="mt-5 rounded-xl border bg-white p-4 text-sm font-semibold">{message}</p>}

    <section className="mt-6 grid gap-5 xl:grid-cols-2">
      <form onSubmit={collect} className="rounded-[1.5rem] bg-[#1464f4] p-6 text-white"><div className="flex items-center gap-3"><Banknote size={19}/><h2 className="text-xl font-black">Collect due / manual payment</h2></div><select required value={form.orderId} onChange={e=>setForm({...form,orderId:e.target.value})} className="mt-5 w-full rounded-xl border border-white/10 bg-white/10 p-3"><option className="text-black" value="">Choose order</option>{orders.filter(o=>!['PAID','REFUNDED'].includes(o.paymentStatus)).map(o=><option className="text-black" key={o.id} value={o.id}>{o.orderNumber} · {o.customerName} · {money(o.total)} · {o.paymentStatus}</option>)}</select><div className="mt-3 grid gap-3 sm:grid-cols-2"><input required type="number" min="0.01" step="0.01" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})} placeholder="Amount" className="rounded-xl border border-white/10 bg-white/10 p-3"/><select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})} className="rounded-xl border border-white/10 bg-white/10 p-3"><option className="text-black">CASH</option><option className="text-black">BANK_TRANSFER</option><option className="text-black">BKASH_MANUAL</option><option className="text-black">NAGAD_MANUAL</option></select></div><input value={form.externalReference} onChange={e=>setForm({...form,externalReference:e.target.value})} placeholder="Reference / transaction ID (optional)" className="mt-3 w-full rounded-xl border border-white/10 bg-white/10 p-3"/><button className="mt-4 rounded-xl bg-white px-5 py-3 text-sm font-black text-slate-950">Record verified payment</button></form>

      <form onSubmit={createRefund} className="rounded-[1.5rem] border border-slate-200 bg-white p-6"><h2 className="text-xl font-black">Create refund</h2><select required value={refund.orderId} onChange={e=>setRefund({...refund,orderId:e.target.value})} className="mt-5 w-full rounded-xl border p-3"><option value="">Choose paid order</option>{orders.filter(o=>['PAID','PARTIAL'].includes(o.paymentStatus)).map(o=><option key={o.id} value={o.id}>{o.orderNumber} · {o.customerName} · {o.paymentStatus}</option>)}</select><input required type="number" min="0.01" step="0.01" value={refund.amount} onChange={e=>setRefund({...refund,amount:e.target.value})} placeholder="Refund amount" className="mt-3 w-full rounded-xl border p-3"/><textarea required value={refund.reason} onChange={e=>setRefund({...refund,reason:e.target.value})} placeholder="Reason" className="mt-3 min-h-20 w-full rounded-xl border p-3"/><button className="mt-3 rounded-xl bg-[#1464f4] px-5 py-3 text-sm font-black text-white">Create refund request</button></form>
    </section>

    <section className="mt-6 overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white"><div className="border-b p-5"><h2 className="text-xl font-black">Payment ledger</h2></div><div className="overflow-x-auto"><table className="w-full min-w-[1000px] text-left text-sm"><thead className="bg-slate-50 text-xs uppercase text-slate-400"><tr><th className="px-5 py-4">Time</th><th>Order</th><th>Type</th><th>Provider</th><th>Amount</th><th>Status</th><th>Reference</th></tr></thead><tbody className="divide-y">{visible.map(x=><tr key={x.id}><td className="px-5 py-4 text-xs">{new Date(x.createdAt).toLocaleString()}</td><td className="font-mono text-xs">{x.orderId}</td><td className="font-black">{pretty(x.type)}</td><td>{x.provider}</td><td className="font-black">{money(x.amount)}</td><td>{pretty(x.status)}</td><td>{x.externalReference||'—'}</td></tr>)}</tbody></table></div></section>

    <section className="mt-6"><h2 className="text-2xl font-black">Refund queue</h2><div className="mt-4 space-y-3">{refunds.map(x=><article key={x.id} className="flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5"><div className="min-w-[260px] flex-1"><p className="font-black">{money(x.amount)} · {pretty(x.status)}</p><p className="mt-1 text-sm text-slate-500">{x.reason}</p><p className="mt-1 font-mono text-[10px] text-slate-400">{x.orderId}</p></div><div className="flex flex-wrap gap-2">{x.status==='REQUESTED'&&<><button onClick={()=>refundStatus(x.id,'APPROVED')} className="rounded-lg border px-3 py-2 text-xs font-black">Approve</button><button onClick={()=>refundStatus(x.id,'REJECTED')} className="rounded-lg border border-rose-200 px-3 py-2 text-xs font-black text-rose-600">Reject</button></>}{x.status==='APPROVED'&&<button onClick={()=>refundStatus(x.id,'COMPLETED')} className="rounded-lg bg-[#1464f4] px-3 py-2 text-xs font-black text-white">Mark completed</button>}</div></article>)}</div></section>
  </AdminShell>
}
