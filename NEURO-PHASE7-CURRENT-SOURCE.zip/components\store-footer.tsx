'use client';

import Link from 'next/link';
import { Mail, MapPin, MessageCircle, Phone, Clock3 } from 'lucide-react';
import { useStoreConfig } from '@/components/store-config-provider';
import { useI18n } from '@/lib/i18n';

function normalizeBangladeshPhone(value:string){
  const digits=(value||'').replace(/\D/g,'');
  if(digits.startsWith('880'))return digits;
  if(digits.startsWith('0'))return `88${digits}`;
  return digits;
}

export default function StoreFooter(){
 const config=useStoreConfig();
 const {t}=useI18n();
 const identity=config['store.identity']||{};
 const footer=config['store.footer']||{};
 const contact=config['store.contact']||{};
 const storeName=identity.storeName||'Neuro Commerce';
 const about=footer.about||'Reliable products, fair prices and fast delivery with a connected shopping experience.';
 const copyright=footer.copyright||`© 2026 ${storeName}. All rights reserved.`;
 const phone=contact.phone||identity.supportPhone||'01764305948';
 const email=contact.email||identity.supportEmail||'meherabjim2022@gmail.com';
 const address=contact.address||'Vatara, Dhaka';
 const facebookUrl=contact.facebookUrl||'https://www.facebook.com/';
 const messengerUrl=contact.messengerUrl||'https://www.messenger.com/';
 const whatsappDigits=normalizeBangladeshPhone(contact.whatsappNumber||phone);
 const supportHours=contact.supportHours||'Every day, 10:00 AM – 10:00 PM';

 return <footer className="mt-20 border-t border-slate-200 bg-[#0d2747] text-white">
  <div className="mx-auto grid max-w-7xl gap-9 px-5 py-12 md:grid-cols-2 xl:grid-cols-4">
   <div>
    <div className="flex items-center gap-3">
     <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#1464f4] text-xl font-black text-white">{storeName.charAt(0).toUpperCase()}</span>
     <div><p className="text-xl font-black">{storeName}</p><p className="mt-1 text-[10px] font-bold uppercase tracking-[.16em] text-white/45">{identity.tagline||'Smart shopping, easy living'}</p></div>
    </div>
    <p className="mt-5 max-w-sm text-sm leading-7 text-white/65">{about}</p>
    <p className="mt-6 text-sm font-black">{t('followUs')}</p>
    <div className="mt-3 flex gap-2">
     <a href={facebookUrl} target="_blank" rel="noreferrer" aria-label="Facebook" className="grid h-10 w-10 place-items-center rounded-full bg-[#1877f2] text-lg font-black text-white transition hover:-translate-y-1">f</a>
     <a href={messengerUrl} target="_blank" rel="noreferrer" aria-label="Messenger" className="grid h-10 w-10 place-items-center rounded-full bg-[#1684ff] text-white transition hover:-translate-y-1"><MessageCircle size={18} fill="currentColor"/></a>
     <a href={`https://wa.me/${whatsappDigits}`} target="_blank" rel="noreferrer" aria-label="WhatsApp" className="grid h-10 w-10 place-items-center rounded-full bg-[#22c55e] text-white transition hover:-translate-y-1"><MessageCircle size={18}/></a>
    </div>
   </div>

   <div>
    <p className="text-sm font-black">{t('quickLinks')}</p>
    <div className="mt-4 space-y-3 text-sm text-white/65">
     <Link className="block hover:text-white" href="/">Home</Link>
     <Link className="block hover:text-white" href="/shop">Shop</Link>
     <Link className="block hover:text-white" href="/shop?sort=new">New Arrivals</Link>
     <Link className="block hover:text-white" href="/shop?offers=1">Offers</Link>
     <Link className="block hover:text-white" href="/pages/about">About us</Link>
     <Link className="block hover:text-white" href="/pages/contact">Contact us</Link>
    </div>
   </div>

   <div>
    <p className="text-sm font-black">{t('customerService')}</p>
    <div className="mt-4 space-y-3 text-sm text-white/65">
     <Link className="block hover:text-white" href="/account">My Orders</Link>
     <Link className="block hover:text-white" href="/account/returns">Return & refund</Link>
     <Link className="block hover:text-white" href="/account/addresses">Delivery information</Link>
     <Link className="block hover:text-white" href="/pages/privacy">Privacy policy</Link>
     <Link className="block hover:text-white" href="/pages/terms">Terms & conditions</Link>
     <Link className="block hover:text-white" href="/pages/help">Help center</Link>
    </div>
   </div>

   <div>
    <p className="text-sm font-black">{t('contactUs')}</p>
    <div className="mt-4 space-y-4 text-sm text-white/70">
     <div className="flex gap-3"><MapPin className="mt-0.5 shrink-0" size={17}/><span>{address}</span></div>
     <a href={`tel:${phone}`} className="flex gap-3 hover:text-white"><Phone className="mt-0.5 shrink-0" size={17}/><span>{phone}</span></a>
     <a href={`mailto:${email}`} className="flex gap-3 break-all hover:text-white"><Mail className="mt-0.5 shrink-0" size={17}/><span>{email}</span></a>
     <div className="flex gap-3"><Clock3 className="mt-0.5 shrink-0" size={17}/><span>{supportHours}</span></div>
    </div>
   </div>
  </div>

  <div className="border-t border-white/10">
   <div className="mx-auto flex max-w-7xl flex-col justify-between gap-4 px-5 py-5 text-xs text-white/50 sm:flex-row sm:items-center">
    <span>{copyright}</span>
    <div className="flex flex-wrap items-center gap-3 font-black">
     <span className="rounded bg-white/10 px-2.5 py-1">bKash</span>
     <span className="rounded bg-white/10 px-2.5 py-1">Nagad</span>
     <span className="rounded bg-white/10 px-2.5 py-1">VISA</span>
     <span className="rounded bg-white/10 px-2.5 py-1">Mastercard</span>
     <span className="rounded bg-white/10 px-2.5 py-1">SSL Secured</span>
    </div>
   </div>
  </div>
 </footer>
}
