﻿import {
  CanActivate,
  ExecutionContext,
  HttpException,
  HttpStatus,
  Injectable,
} from '@nestjs/common';

type Bucket = {
  count: number;
  resetAt: number;
};

@Injectable()
export class RateLimitGuard implements CanActivate {

  private readonly buckets =
    new Map<string, Bucket>();


  canActivate(
    context: ExecutionContext,
  ): boolean {

    const request =
      context
        .switchToHttp()
        .getRequest();


    const ip =
      request.ip ||
      request.headers['x-forwarded-for'] ||
      request.socket?.remoteAddress ||
      'unknown';


    const route =
      `${request.method}:${
        request.route?.path ||
        request.url ||
        ''
      }`;


    const key =
      `${ip}:${route}`;


    const now =
      Date.now();


    const windowMs =
      Number(
        process.env
          .RATE_LIMIT_WINDOW_MS ||
        60000,
      );


    const limit =
      Number(
        process.env
          .RATE_LIMIT_MAX ||
        120,
      );


    let bucket =
      this.buckets.get(key);


    if (
      !bucket ||
      bucket.resetAt <= now
    ) {

      bucket = {
        count: 0,
        resetAt:
          now + windowMs,
      };

      this.buckets.set(
        key,
        bucket,
      );
    }


    bucket.count += 1;


    if (
      bucket.count > limit
    ) {

      throw new HttpException(
        'Too many requests. Please try again shortly.',
        HttpStatus.TOO_MANY_REQUESTS,
      );
    }


    return true;
  }
}
