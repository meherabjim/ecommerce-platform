'use client';

import { useEffect,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Heart, Trash2 } from 'lucide-react';
import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

export default function WishlistPage(){
  const router=useRouter();const [items,setItems]=useState<any[]>([]);
  async function load(){const r=await api.get('/wishlist');setItems(r.data||[])}
  useEffect(()=>{if(!getStoredUser()){router.replace('/login');return}load()},[router]);
  async function remove(id:string){await api.delete(`/wishlist/${id}`);await load()}
  return <main className="min-h-screen text-slate-950"><Navbar/><AccountShell>
    <div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Saved for later</p><h1 className="mt-2 text-4xl font-black">Wishlist</h1><p className="mt-2 text-sm text-slate-500">{items.length} saved product{items.length===1?'':'s'}.</p></div>
    <div className="mt-6 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">{items.map((item:any)=>{
      const p=item.product;if(!p)return null;const v=p.variants?.[0];const image=v?.imageUrl||p.primaryImageUrl;
      return <article key={item.id} className="overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white">
        <Link href={`/shop/${p.slug}`} className="block overflow-hidden bg-slate-100">{image?<img src={image} alt={p.name} className="aspect-[4/3] w-full object-cover"/>:<div className="grid aspect-[4/3] place-items-center text-6xl font-black text-slate-300">{p.name?.[0]}</div>}</Link>
        <div className="p-5"><p className="text-[10px] font-black uppercase tracking-[.15em] text-slate-400">Saved product</p><Link href={`/shop/${p.slug}`} className="mt-2 block text-lg font-black">{p.name}</Link>{v&&<p className="mt-2 text-lg font-black">BDT {v.salePrice||v.price}</p>}
        <div className="mt-5 flex gap-2"><Link href={`/shop/${p.slug}`} className="flex-1 rounded-xl bg-[#1464f4] px-4 py-3 text-center text-sm font-black text-white">View product</Link><button onClick={()=>remove(p.id)} className="grid w-12 place-items-center rounded-xl border border-rose-200 text-rose-600"><Trash2 size={17}/></button></div></div>
      </article>
    })}</div>
    {!items.length&&<div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center"><Heart className="mx-auto text-slate-300"/><p className="mt-4 text-lg font-black">Your wishlist is empty</p><Link href="/shop" className="mt-4 inline-block rounded-xl bg-[#1464f4] px-5 py-3 text-sm font-black text-white">Explore products</Link></div>}
  </AccountShell><StoreFooter/></main>
}
