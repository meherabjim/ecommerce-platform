'use client';
import { useEffect,useState } from 'react';
import { useParams,useRouter } from 'next/navigation';
import Navbar from '@/components/navbar';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const money=(v:any)=>`BDT ${Number(v||0).toLocaleString(undefined,{maximumFractionDigits:2})}`;
export default function InvoicePage(){
 const {id}=useParams<{id:string}>();const router=useRouter();const [d,setD]=useState<any>(null);
 useEffect(()=>{if(!getStoredUser()){router.replace('/login');return}api.get(`/ops/invoices/${id}`).then(r=>setD(r.data))},[id,router]);
 if(!d)return <main className="grid min-h-screen place-items-center">Loading invoice...</main>;
 return <main className="min-h-screen bg-[#f5f6f8]"><div className="print:hidden"><Navbar/></div><div className="mx-auto max-w-4xl px-5 py-10"><div className="mb-5 flex justify-end print:hidden"><button onClick={()=>window.print()} className="rounded-xl bg-[#1464f4] px-4 py-3 text-sm font-black text-white">Print invoice</button></div><article className="rounded-[2rem] border bg-white p-7 print:border-0"><div className="flex justify-between gap-5 border-b pb-6"><div><p className="text-xs font-black uppercase text-slate-400">Invoice</p><h1 className="mt-2 text-3xl font-black">{d.invoiceNumber}</h1><p className="text-sm text-slate-500">Order {d.order.orderNumber}</p></div><div className="text-right text-sm"><b>Neuro Commerce</b><p className="text-slate-500">{new Date(d.issuedAt).toLocaleString()}</p></div></div><div className="grid gap-6 border-b py-6 sm:grid-cols-2"><div><p className="text-xs font-black uppercase text-slate-400">Bill to</p><p className="mt-2 font-black">{d.order.customerName}</p><p className="text-sm text-slate-500">{d.order.email}</p></div><div><p className="text-xs font-black uppercase text-slate-400">Deliver to</p><p className="mt-2 text-sm">{d.order.addressLine}</p><p className="text-sm text-slate-500">{[d.order.area,d.order.district,d.order.division].filter(Boolean).join(', ')}</p></div></div><table className="my-6 w-full text-left text-sm"><thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Total</th></tr></thead><tbody>{d.items.map((x:any)=><tr key={x.id} className="border-t"><td className="py-4 font-black">{x.productName}</td><td>{x.quantity}</td><td>{money(x.unitPrice)}</td><td>{money(x.lineTotal)}</td></tr>)}</tbody></table><div className="ml-auto max-w-sm space-y-2 border-t pt-5 text-sm"><div className="flex justify-between"><span>Total</span><b>{money(d.order.total)}</b></div><div className="flex justify-between"><span>Net paid</span><b>{money(d.payment.netPaid)}</b></div><div className="flex justify-between"><span>Due</span><b>{money(d.payment.due)}</b></div></div></article></div><div className="print:hidden"><StoreFooter/></div></main>
}
