'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Bell, CheckCheck } from 'lucide-react';

import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';

import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';


export default function NotificationsPage() {
  const router = useRouter();

  const [items, setItems] = useState<any[]>([]);


  async function load() {
    const r = await api.get('/notifications');
    setItems(r.data || []);
  }


  useEffect(() => {
    if (!getStoredUser()) {
      router.replace('/login');
      return;
    }

    load();
  }, [router]);


  async function read(id: string) {
    await api.patch(`/notifications/${id}/read`);
    await load();
  }


  async function markAll() {
    await api.patch('/notifications/read-all');
    await load();
  }


  const unread = items.filter(
    (x) => !x.isRead
  ).length;


  return (
    <main className="min-h-screen text-slate-950">
      
      <Navbar />

      <AccountShell>

        <div className="flex flex-wrap items-end justify-between gap-4">

          <div>

            <p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">
              Customer portal
            </p>


            <button
              onClick={markAll}
              className="float-right rounded-xl border px-4 py-2 text-xs font-black"
            >
              Mark all read
            </button>


            <h1 className="mt-2 text-4xl font-black">
              Notifications
            </h1>


            <p className="mt-2 text-sm text-slate-500">
              Order, payment, delivery and return updates.
            </p>

          </div>


          <span className="rounded-full bg-[#1464f4] px-3 py-2 text-xs font-black text-white">
            {unread} unread
          </span>

        </div>



        <section className="mt-6 space-y-3">


          {items.map((x) => (

            <button
              key={x.id}
              onClick={() => read(x.id)}
              className={`flex w-full gap-4 rounded-2xl border p-5 text-left transition ${
                x.isRead
                  ? 'border-slate-200 bg-white'
                  : 'border-[#1464f4] bg-slate-50'
              }`}
            >


              <span
                className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${
                  x.isRead
                    ? 'bg-slate-100 text-slate-500'
                    : 'bg-[#1464f4] text-white'
                }`}
              >

                {
                  x.isRead
                    ? <CheckCheck size={18}/>
                    : <Bell size={18}/>
                }

              </span>



              <div className="min-w-0 flex-1">


                <div className="flex items-start justify-between gap-3">

                  <p className="font-black">
                    {x.title}
                  </p>


                  {
                    !x.isRead &&
                    (
                      <span className="rounded-full bg-rose-600 px-2 py-1 text-[9px] font-black text-white">
                        NEW
                      </span>
                    )
                  }

                </div>



                <p className="mt-2 text-sm leading-6 text-slate-500">
                  {x.message}
                </p>


                <p className="mt-3 text-[10px] font-black uppercase tracking-[.14em] text-slate-300">
                  {x.type}
                </p>


              </div>


            </button>

          ))}



          {
            !items.length &&
            (
              <div className="rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center">

                <Bell className="mx-auto text-slate-300"/>

                <p className="mt-4 font-black">
                  No notifications yet
                </p>

              </div>
            )
          }


        </section>


      </AccountShell>


      <StoreFooter />

    </main>
  );
}