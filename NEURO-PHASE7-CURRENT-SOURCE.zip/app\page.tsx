'use client';

import { useEffect,useMemo,useState } from 'react';
import Link from 'next/link';
import { ArrowRight, PackageCheck, RefreshCw, ShieldCheck, Truck } from 'lucide-react';
import Navbar from '@/components/navbar';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { useI18n } from '@/lib/i18n';
import { localizedCategoryName, localizedProductName } from '@/lib/localized';

export default function Home(){
  const {language,t}=useI18n();
  const [products,setProducts]=useState<any[]>([]);
  const [promos,setPromos]=useState<any[]>([]);
  const [categories,setCategories]=useState<any[]>([]);
  const [cms,setCms]=useState<any>({settings:{},sections:[],blocks:[],pages:[]});

  useEffect(()=>{
    Promise.all([
      api.get('/catalog/public/products'),
      api.get('/promotions/public/featured'),
      api.get('/catalog/public/categories'),
      api.get('/cms/public/home'),
    ]).then(([p,c,k,m])=>{
      setProducts(p.data||[]);setPromos(c.data||[]);setCategories(k.data||[]);setCms(m.data||{settings:{},sections:[],blocks:[],pages:[]});
    }).catch(()=>{});
  },[]);

  const featured=useMemo(()=>{const list=products.filter((x:any)=>x.featured);return list.length?list:products},[products]);
  const blocksByKind=(kind:string)=>(cms.blocks||[]).filter((x:any)=>x.kind===kind);
  const sections=(cms.sections||[]).length?cms.sections:[
    {id:'hero',type:'HERO',title:'Everything you need, in one modern store.',subtitle:'Discover products, save favorites, checkout securely, track delivery and manage returns from one connected account.',config:{titleBn:'আপনার প্রয়োজনের সবকিছু, এক আধুনিক স্টোরে।',subtitleBn:'পণ্য খুঁজুন, পছন্দের পণ্য সেভ করুন, নিরাপদে চেকআউট করুন, ডেলিভারি ট্র্যাক করুন এবং রিটার্ন পরিচালনা করুন—এক অ্যাকাউন্ট থেকেই।',primaryCtaLabel:'Shop now',primaryCtaLabelBn:'এখনই শপ করুন',primaryCtaUrl:'/shop',secondaryCtaLabel:'Track an order',secondaryCtaLabelBn:'অর্ডার ট্র্যাক করুন',secondaryCtaUrl:'/account'}},
    {id:'trust',type:'TRUST_STRIP',config:{}},
    {id:'categories',type:'CATEGORIES',title:'Shop by category',subtitle:'Browse faster',config:{titleBn:'ক্যাটাগরি অনুযায়ী কেনাকাটা',subtitleBn:'দ্রুত খুঁজুন',limit:8}},
    {id:'featured',type:'FEATURED_PRODUCTS',title:'Featured products',subtitle:'Curated for you',config:{titleBn:'ফিচার্ড পণ্য',subtitleBn:'আপনার জন্য বাছাই করা',limit:8}},
  ];

  const localizedSection=(section:any,key:'title'|'subtitle')=> language==='bn'?(section.config?.[`${key}Bn`]||section[key]||''):(section[key]||'');
  const localizedCfg=(cfg:any,key:string,fallbackEn:string,fallbackBn:string)=>language==='bn'?(cfg?.[`${key}Bn`]||fallbackBn):(cfg?.[key]||fallbackEn);

  function renderSection(section:any){
    const cfg=section.config||{};
    if(section.type==='HERO'){
      const title=localizedSection(section,'title') || (language==='bn'?'আপনার প্রয়োজনের সবকিছু, এক আধুনিক স্টোরে।':'Everything you need, in one modern store.');
      const subtitle=localizedSection(section,'subtitle') || (language==='bn'?'বিশ্বস্ত কেনাকাটা, দ্রুত ডেলিভারি এবং সহজ রিটার্ন—সব এক জায়গায়।':'Reliable shopping, fast delivery and easy returns in one connected store.');
      return <section key={section.id} className="mx-auto max-w-7xl px-5 pt-6">
        <div className="grid gap-4 lg:grid-cols-[250px_minmax(0,1fr)]">
          <aside className="hidden overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm lg:block">
            <div className="flex items-center gap-2 bg-[#1464f4] px-4 py-3.5 text-sm font-black text-white"><span className="text-lg">☰</span>{language==='bn'?'সব ক্যাটাগরি':'All categories'}</div>
            <div className="divide-y divide-slate-100">
              {categories.slice(0,9).map((c:any)=><Link key={c.id} href={`/shop?category=${c.id}`} className="flex items-center justify-between px-4 py-3 text-sm font-bold text-slate-600 hover:bg-blue-50 hover:text-[#1464f4]"><span>{localizedCategoryName(language,c)}</span><span className="text-slate-300">›</span></Link>)}
              <Link href="/shop" className="block px-4 py-3 text-sm font-black text-[#1464f4]">{language==='bn'?'সব ক্যাটাগরি দেখুন':'View all categories'} →</Link>
            </div>
          </aside>

          <div className="relative grid min-h-[390px] overflow-hidden rounded-[1.75rem] border border-blue-100 bg-gradient-to-br from-[#eef6ff] via-[#e7f1ff] to-[#d8eaff] lg:grid-cols-[1.05fr_.95fr]">
            <div className="relative z-10 flex flex-col justify-center p-7 sm:p-10 lg:p-12">
              <div className="inline-flex w-fit items-center gap-2 rounded-full bg-blue-100 px-3 py-2 text-[11px] font-black uppercase tracking-[.16em] text-[#1464f4]">🔥 {localizedCfg(cfg,'eyebrow','SUPER OFFER','সুপার অফার')}</div>
              <h1 className="mt-5 max-w-2xl text-4xl font-black leading-[1.06] tracking-[-.035em] text-[#123a78] sm:text-5xl lg:text-6xl">{title}</h1>
              {subtitle&&<p className="mt-5 max-w-xl text-base leading-7 text-slate-600 sm:text-lg">{subtitle}</p>}
              <div className="mt-7 flex flex-wrap gap-3">
                <Link href={cfg.primaryCtaUrl||'/shop'} className="inline-flex items-center gap-2 rounded-xl bg-[#1464f4] px-5 py-3.5 text-sm font-black text-white shadow-lg shadow-blue-200">{localizedCfg(cfg,'primaryCtaLabel','Shop now','এখনই শপ করুন')} <ArrowRight size={17}/></Link>
                {(cfg.secondaryCtaUrl||'/account')&&<Link href={cfg.secondaryCtaUrl||'/account'} className="rounded-xl border border-blue-200 bg-white/75 px-5 py-3.5 text-sm font-black text-[#123a78]">{localizedCfg(cfg,'secondaryCtaLabel','Track an order','অর্ডার ট্র্যাক করুন')}</Link>}
              </div>
            </div>
            <div className="relative min-h-[280px] p-5 lg:min-h-full lg:p-8">
              {cfg.backgroundImage&&<img src={cfg.backgroundImage} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30"/>}
              <div className="absolute right-8 top-8 h-64 w-64 rounded-full bg-[#7ab6ff]/35 blur-2xl"/>
              <div className="relative grid h-full grid-cols-2 content-center gap-3">
                {featured.slice(0,4).map((p:any)=>{const v=p.variants?.[0];const image=v?.imageUrl||(Array.isArray(p.media)?p.media.find((m:any)=>m.type==='image')?.url:null)||p.primaryImageUrl;const name=localizedProductName(language,p);return <Link key={p.id} href={`/shop/${p.slug}`} className="overflow-hidden rounded-2xl border border-white/80 bg-white/80 shadow-lg backdrop-blur transition hover:-translate-y-1">
                  {image?<img src={image} alt={name} className="aspect-square w-full object-cover"/>:<div className="grid aspect-square place-items-center bg-white text-5xl font-black text-blue-100">{name?.[0]}</div>}
                  <div className="p-3"><p className="truncate text-xs font-black text-slate-800">{name}</p><p className="mt-1 text-[11px] font-bold text-[#1464f4]">{v?`${language==='bn'?'৳':'BDT '}${v.salePrice||v.price}`:(language==='bn'?'অপশন দেখুন':'View options')}</p></div>
                </Link>})}
              </div>
            </div>
          </div>
        </div>
      </section>
    }

    if(section.type==='TRUST_STRIP'){
      const defaults=language==='bn'?[{title:'দ্রুত ডেলিভারি',subtitle:'এলাকাভিত্তিক ডেলিভারি',Icon:Truck},{title:'নিরাপদ কেনাকাটা',subtitle:'সুরক্ষিত অ্যাকাউন্ট ব্যবস্থা',Icon:ShieldCheck},{title:'সহজ রিটার্ন',subtitle:'রিটার্ন স্ট্যাটাস দেখুন',Icon:RefreshCw},{title:'লাইভ স্টক',subtitle:'ভ্যারিয়েন্টভিত্তিক স্টক',Icon:PackageCheck}]:[{title:'Fast delivery',subtitle:'Zone-based shipping',Icon:Truck},{title:'Secure shopping',subtitle:'Protected account flow',Icon:ShieldCheck},{title:'Easy returns',subtitle:'Track return status',Icon:RefreshCw},{title:'Live stock',subtitle:'Variant-level availability',Icon:PackageCheck}];
      const items=(cfg.items||[]).length?cfg.items:defaults;
      return <section key={section.id} className="mx-auto max-w-7xl px-5 py-6"><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{items.map((item:any,index:number)=>{const Icon=defaults[index%defaults.length].Icon;return <div key={`${item.title}-${index}`} className="premium-card flex items-center gap-4 rounded-2xl p-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1464f4] text-white"><Icon size={19}/></span><div><p className="text-sm font-black">{language==='bn'?(item.titleBn||item.title):item.title}</p><p className="mt-1 text-xs text-slate-500">{language==='bn'?(item.subtitleBn||item.subtitle):item.subtitle}</p></div></div>})}</div></section>
    }

    if(section.type==='CATEGORIES'&&categories.length){
      return <section key={section.id} className="mx-auto max-w-7xl px-5 py-8"><div className="flex items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">{localizedSection(section,'subtitle')||(language==='bn'?'দ্রুত খুঁজুন':'Browse faster')}</p><h2 className="mt-2 text-3xl font-black tracking-tight">{localizedSection(section,'title')||(language==='bn'?'ক্যাটাগরি অনুযায়ী কেনাকাটা':'Shop by category')}</h2></div><Link href="/shop" className="text-sm font-black">{language==='bn'?'সব দেখুন':'View all'} →</Link></div>
      <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{categories.slice(0,Number(cfg.limit||8)).map((c:any)=><Link key={c.id} href={`/shop?category=${c.id}`} className="group premium-card rounded-2xl p-5 transition hover:-translate-y-1"><p className="text-xs font-bold uppercase tracking-[.16em] text-slate-400">{language==='bn'?'ক্যাটাগরি':'Category'}</p><p className="mt-8 text-xl font-black">{localizedCategoryName(language,c)}</p><p className="mt-2 text-sm text-slate-500">{language==='bn'?'পণ্যগুলো দেখুন':'Explore collection'} <span className="transition group-hover:ml-1">→</span></p></Link>)}</div></section>
    }

    if(section.type==='PROMOTIONS'&&promos.length){return <section key={section.id} className="mx-auto max-w-7xl px-5 py-8"><div className="grid gap-4 lg:grid-cols-2">{promos.slice(0,Number(cfg.limit||2)).map((x:any)=><div key={x.id} className="overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white p-7 premium-shadow"><p className="text-xs font-black uppercase tracking-[.18em] text-amber-600">{language==='bn'?'সীমিত সময়ের অফার':'Limited offer'}</p><h2 className="mt-3 text-3xl font-black">{language==='bn'?(x.nameBn||x.name):x.name}</h2><div className="mt-5 flex flex-wrap items-center gap-3"><span className="rounded-xl bg-[#1464f4] px-4 py-2 font-mono text-sm font-black text-white">{x.code}</span><span className="text-sm font-bold text-slate-500">{x.type==='PERCENT'?`${x.value}% ${language==='bn'?'ছাড়':'off'}`:`${language==='bn'?'৳':'BDT '}${x.value} ${language==='bn'?'ছাড়':'off'}`} · {language==='bn'?'ন্যূনতম':'Min BDT'} {x.minOrder}</span></div></div>)}</div></section>}

    if(section.type==='FEATURED_PRODUCTS'){return <section key={section.id} className="mx-auto max-w-7xl px-5 py-12"><div className="flex items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">{localizedSection(section,'subtitle')||(language==='bn'?'আপনার জন্য বাছাই করা':'Curated for you')}</p><h2 className="mt-2 text-3xl font-black tracking-tight">{localizedSection(section,'title')||(language==='bn'?'ফিচার্ড পণ্য':'Featured products')}</h2></div><Link href="/shop" className="text-sm font-black">{language==='bn'?'সব পণ্য দেখুন':'Shop all'} →</Link></div><div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{featured.slice(0,Number(cfg.limit||8)).map((p:any)=>{const v=p.variants?.[0];const image=v?.imageUrl||(Array.isArray(p.media)?p.media.find((m:any)=>m.type==='image')?.url:null)||p.primaryImageUrl;const name=localizedProductName(language,p);return <Link key={p.id} href={`/shop/${p.slug}`} className="group overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white transition hover:-translate-y-1 hover:shadow-xl"><div className="relative overflow-hidden bg-slate-100">{image?<img src={image} alt={name} className="aspect-[4/3] w-full object-cover transition duration-500 group-hover:scale-[1.04]"/>:<div className="grid aspect-[4/3] place-items-center bg-gradient-to-br from-slate-100 to-slate-200 text-6xl font-black text-slate-300">{name?.[0]}</div>}</div><div className="p-5"><p className="text-[10px] font-black uppercase tracking-[.16em] text-slate-400">{p.category?localizedCategoryName(language,p.category):(language==='bn'?'পণ্য':'Product')}</p><h3 className="mt-2 text-lg font-black">{name}</h3>{v&&<p className="mt-3 font-black">{language==='bn'?'৳':'BDT '}{v.salePrice||v.price}</p>}</div></Link>})}</div></section>}

    if(section.type==='TESTIMONIALS'){const list=blocksByKind('TESTIMONIAL').slice(0,Number(cfg.limit||3));if(!list.length)return null;return <section key={section.id} className="mx-auto max-w-7xl px-5 py-12"><div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">{language==='bn'?'ক্রেতার মতামত':'Social proof'}</p><h2 className="mt-2 text-3xl font-black">{localizedSection(section,'title')||(language==='bn'?'ক্রেতারা যা বলেন':'What customers say')}</h2></div><div className="mt-6 grid gap-4 md:grid-cols-3">{list.map((x:any)=><article key={x.id} className="rounded-[1.5rem] border border-slate-200 bg-white p-6"><div className="text-amber-500">{'★'.repeat(Number(x.metadata?.rating||5))}</div><p className="mt-4 text-sm leading-7 text-slate-600">{language==='bn'?(x.metadata?.bodyBn||x.body):x.body}</p><p className="mt-5 font-black">{language==='bn'?(x.metadata?.titleBn||x.title):x.title}</p><p className="text-xs text-slate-400">{language==='bn'?(x.metadata?.subtitleBn||x.subtitle):x.subtitle}</p></article>)}</div></section>}

    if(section.type==='FAQ'){const list=blocksByKind('FAQ').slice(0,Number(cfg.limit||6));if(!list.length)return null;return <section key={section.id} className="mx-auto max-w-5xl px-5 py-12"><div className="text-center"><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">{language==='bn'?'সহায়তা প্রয়োজন?':'Need help?'}</p><h2 className="mt-2 text-3xl font-black">{localizedSection(section,'title')||(language==='bn'?'সাধারণ জিজ্ঞাসা':'Frequently asked questions')}</h2></div><div className="mt-7 space-y-3">{list.map((x:any)=><details key={x.id} className="rounded-2xl border border-slate-200 bg-white p-5"><summary className="cursor-pointer font-black">{language==='bn'?(x.metadata?.titleBn||x.title):x.title}</summary><p className="mt-3 text-sm leading-6 text-slate-500">{language==='bn'?(x.metadata?.bodyBn||x.body):x.body}</p></details>)}</div></section>}

    if(section.type==='BANNER'){return <section key={section.id} className="mx-auto max-w-7xl px-5 py-8"><div className="relative overflow-hidden rounded-[1.75rem] bg-[#1464f4] p-8 text-white sm:p-10">{cfg.imageUrl&&<img src={cfg.imageUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30"/>}<div className="relative max-w-2xl"><h2 className="text-3xl font-black">{localizedSection(section,'title')}</h2>{localizedSection(section,'subtitle')&&<p className="mt-3 text-white/70">{localizedSection(section,'subtitle')}</p>}{cfg.ctaUrl&&<Link href={cfg.ctaUrl} className="mt-5 inline-block rounded-xl bg-white px-5 py-3 text-sm font-black text-slate-950">{localizedCfg(cfg,'ctaLabel','Explore','দেখুন')}</Link>}</div></div></section>}
    return null;
  }

  return <main className="min-h-screen text-slate-950"><Navbar/>{sections.map(renderSection)}<StoreFooter/></main>
}
