'use client';

import { FormEvent,useEffect,useMemo,useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Eye, GripVertical, Layers3, Plus, Save, Settings2, Trash2,
} from 'lucide-react';
import AdminShell from '@/components/admin-shell';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const pretty=(v:string)=>String(v||'').replaceAll('_',' ').toLowerCase().replace(/\b\w/g,x=>x.toUpperCase());

export default function CmsAdminPage(){
  const router=useRouter();
  const [tab,setTab]=useState<'homepage'|'content'|'pages'|'settings'>('homepage');
  const [settings,setSettings]=useState<any[]>([]);
  const [sections,setSections]=useState<any[]>([]);
  const [blocks,setBlocks]=useState<any[]>([]);
  const [pages,setPages]=useState<any[]>([]);
  const [message,setMessage]=useState('');

  async function load(){
    const [s,h,b,p]=await Promise.all([
      api.get('/cms/admin/settings'),
      api.get('/cms/admin/sections'),
      api.get('/cms/admin/blocks'),
      api.get('/cms/admin/pages'),
    ]);
    setSettings(s.data||[]);setSections(h.data||[]);setBlocks(b.data||[]);setPages(p.data||[]);
  }
  useEffect(()=>{const u=getStoredUser();if(!u||!['SUPER_ADMIN','ADMIN','MARKETING_MANAGER'].includes(String(u.role).toUpperCase())){router.replace('/admin?denied=1');return}load()},[router]);

  async function saveSetting(row:any){
    try{await api.patch(`/cms/admin/settings/${encodeURIComponent(row.key)}`,{value:row.value,groupName:row.groupName,description:row.description||undefined});setMessage(`${row.key} saved.`);await load()}catch(e:any){setMessage(e?.response?.data?.message||'Save failed.')}
  }

  async function patchSection(row:any){
    try{await api.patch(`/cms/admin/sections/${row.id}`,{type:row.type,title:row.title||undefined,subtitle:row.subtitle||undefined,enabled:row.enabled,sortOrder:Number(row.sortOrder||0),config:row.config||{}});setMessage('Homepage section saved.');await load()}catch(e:any){setMessage(e?.response?.data?.message||'Section save failed.')}
  }

  async function addSection(){
    await api.post('/cms/admin/sections',{type:'BANNER',title:'New homepage section',subtitle:'Edit this section',enabled:true,sortOrder:(sections.at(-1)?.sortOrder||0)+10,config:{ctaLabel:'Explore',ctaUrl:'/shop'}});
    await load();
  }

  async function deleteSection(id:string){if(!confirm('Delete this homepage section?'))return;await api.delete(`/cms/admin/sections/${id}`);await load()}

  async function addBlock(kind:string){
    await api.post('/cms/admin/blocks',{kind,title:`New ${pretty(kind)}`,body:'Edit this content.',active:true,sortOrder:(blocks.filter(x=>x.kind===kind).at(-1)?.sortOrder||0)+10,metadata:kind==='TESTIMONIAL'?{rating:5}:{}});
    await load();
  }
  async function saveBlock(row:any){await api.patch(`/cms/admin/blocks/${row.id}`,{kind:row.kind,title:row.title,subtitle:row.subtitle||undefined,body:row.body||undefined,imageUrl:row.imageUrl||undefined,linkLabel:row.linkLabel||undefined,linkUrl:row.linkUrl||undefined,active:row.active,sortOrder:Number(row.sortOrder||0),metadata:row.metadata||{}});setMessage('Content saved.');await load()}
  async function deleteBlock(id:string){if(!confirm('Delete this content item?'))return;await api.delete(`/cms/admin/blocks/${id}`);await load()}

  async function addPage(){
    await api.post('/cms/admin/pages',{slug:`new-page-${Date.now()}`,title:'New page',body:'Edit this page content.',status:'DRAFT',sortOrder:(pages.at(-1)?.sortOrder||0)+10});
    await load();
  }
  async function savePage(row:any){await api.patch(`/cms/admin/pages/${row.id}`,{slug:row.slug,title:row.title,body:row.body,status:row.status,metaTitle:row.metaTitle||undefined,metaDescription:row.metaDescription||undefined,sortOrder:Number(row.sortOrder||0)});setMessage('CMS page saved.');await load()}
  async function deletePage(id:string){if(!confirm('Delete this page?'))return;await api.delete(`/cms/admin/pages/${id}`);await load()}

  function updateSetting(index:number,key:string,value:any){setSettings(s=>s.map((x,i)=>i===index?{...x,[key]:value}:x))}
  function updateSection(index:number,key:string,value:any){setSections(s=>s.map((x,i)=>i===index?{...x,[key]:value}:x))}
  function updateBlock(index:number,key:string,value:any){setBlocks(s=>s.map((x,i)=>i===index?{...x,[key]:value}:x))}
  function updatePage(index:number,key:string,value:any){setPages(s=>s.map((x,i)=>i===index?{...x,[key]:value}:x))}

  return <AdminShell>
    <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
      <div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">SRS configurability</p><h1 className="mt-2 text-4xl font-black tracking-tight">CMS & Store Builder</h1><p className="mt-2 max-w-3xl text-sm text-slate-500">Manage homepage sections, banners, FAQ, testimonials, policy pages, brand identity, theme tokens, business and SEO settings.</p></div>
      <a href="/" target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl bg-slate-950 px-5 py-3 text-sm font-black text-white"><Eye size={16}/>Open storefront</a>
    </div>

    {message&&<p className="mt-5 rounded-xl border border-slate-200 bg-white p-4 text-sm font-semibold">{message}</p>}

    <div className="mt-6 flex flex-wrap gap-2">
      {([['homepage','Homepage'],['content','FAQ / Testimonials'],['pages','CMS Pages'],['settings','Brand & Settings']] as const).map(([v,l])=><button key={v} onClick={()=>setTab(v)} className={`rounded-xl px-4 py-3 text-sm font-black ${tab===v?'bg-slate-950 text-white':'border border-slate-200 bg-white'}`}>{l}</button>)}
    </div>

    {tab==='homepage'&&<section className="mt-6">
      <div className="flex items-center justify-between"><div><h2 className="text-2xl font-black">Homepage Builder</h2><p className="text-sm text-slate-500">Enable, order and configure dynamic storefront sections.</p></div><button onClick={addSection} className="flex items-center gap-2 rounded-xl bg-slate-950 px-4 py-3 text-sm font-black text-white"><Plus size={15}/>Add section</button></div>
      <div className="mt-5 space-y-4">{sections.map((row:any,index:number)=><article key={row.id} className="rounded-[1.5rem] border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center gap-3"><GripVertical className="text-slate-300"/><span className="rounded-full bg-slate-100 px-3 py-1 text-[10px] font-black">{row.type}</span><label className="ml-auto flex items-center gap-2 text-xs font-black"><input type="checkbox" checked={row.enabled} onChange={e=>updateSection(index,'enabled',e.target.checked)}/>Enabled</label></div>
        <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4"><label className="text-xs font-black">Type<input value={row.type} onChange={e=>updateSection(index,'type',e.target.value.toUpperCase())} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Title<input value={row.title||''} onChange={e=>updateSection(index,'title',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Subtitle<input value={row.subtitle||''} onChange={e=>updateSection(index,'subtitle',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Order<input type="number" value={row.sortOrder} onChange={e=>updateSection(index,'sortOrder',Number(e.target.value))} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label></div>
        <label className="mt-3 block text-xs font-black">Config JSON<textarea value={JSON.stringify(row.config||{},null,2)} onChange={e=>{try{updateSection(index,'config',JSON.parse(e.target.value))}catch{}}} className="mt-2 min-h-28 w-full rounded-xl border bg-slate-50 p-3 font-mono text-xs"/></label>
        <div className="mt-4 flex gap-2"><button onClick={()=>patchSection(row)} className="flex items-center gap-2 rounded-xl bg-slate-950 px-4 py-2.5 text-xs font-black text-white"><Save size={14}/>Save</button><button onClick={()=>deleteSection(row.id)} className="flex items-center gap-2 rounded-xl border border-rose-200 px-4 py-2.5 text-xs font-black text-rose-600"><Trash2 size={14}/>Delete</button></div>
      </article>)}</div>
    </section>}

    {tab==='content'&&<section className="mt-6 space-y-8">
      {['FAQ','TESTIMONIAL','BANNER'].map(kind=><div key={kind}><div className="flex items-center justify-between"><div><h2 className="text-2xl font-black">{pretty(kind)}</h2><p className="text-sm text-slate-500">Reusable storefront content blocks.</p></div><button onClick={()=>addBlock(kind)} className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-black">+ Add {pretty(kind)}</button></div>
      <div className="mt-4 grid gap-4 xl:grid-cols-2">{blocks.filter(x=>x.kind===kind).map((row:any)=>{const index=blocks.findIndex(x=>x.id===row.id);return <article key={row.id} className="rounded-[1.5rem] border border-slate-200 bg-white p-5"><div className="grid gap-3 sm:grid-cols-2"><label className="text-xs font-black">Title<input value={row.title} onChange={e=>updateBlock(index,'title',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Subtitle<input value={row.subtitle||''} onChange={e=>updateBlock(index,'subtitle',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label></div><label className="mt-3 block text-xs font-black">Body<textarea value={row.body||''} onChange={e=>updateBlock(index,'body',e.target.value)} className="mt-2 min-h-24 w-full rounded-xl border p-3 font-normal"/></label><div className="mt-3 grid gap-3 sm:grid-cols-2"><label className="text-xs font-black">Image URL<input value={row.imageUrl||''} onChange={e=>updateBlock(index,'imageUrl',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Order<input type="number" value={row.sortOrder} onChange={e=>updateBlock(index,'sortOrder',Number(e.target.value))} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label></div><div className="mt-4 flex items-center gap-3"><label className="text-xs font-black"><input type="checkbox" checked={row.active} onChange={e=>updateBlock(index,'active',e.target.checked)}/> Active</label><button onClick={()=>saveBlock(row)} className="ml-auto rounded-xl bg-slate-950 px-4 py-2.5 text-xs font-black text-white">Save</button><button onClick={()=>deleteBlock(row.id)} className="rounded-xl border border-rose-200 px-4 py-2.5 text-xs font-black text-rose-600">Delete</button></div></article>})}</div></div>)}
    </section>}

    {tab==='pages'&&<section className="mt-6"><div className="flex items-center justify-between"><div><h2 className="text-2xl font-black">CMS Pages</h2><p className="text-sm text-slate-500">About, policies and other information pages.</p></div><button onClick={addPage} className="rounded-xl bg-slate-950 px-4 py-3 text-sm font-black text-white">+ Add page</button></div>
    <div className="mt-5 space-y-4">{pages.map((row:any,index:number)=><article key={row.id} className="rounded-[1.5rem] border border-slate-200 bg-white p-5"><div className="grid gap-3 md:grid-cols-3"><label className="text-xs font-black">Title<input value={row.title} onChange={e=>updatePage(index,'title',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Slug<input value={row.slug} onChange={e=>updatePage(index,'slug',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Status<select value={row.status} onChange={e=>updatePage(index,'status',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"><option>DRAFT</option><option>PUBLISHED</option><option>ARCHIVED</option></select></label></div><label className="mt-3 block text-xs font-black">Content<textarea value={row.body} onChange={e=>updatePage(index,'body',e.target.value)} className="mt-2 min-h-36 w-full rounded-xl border p-3 font-normal"/></label><div className="mt-3 grid gap-3 md:grid-cols-2"><label className="text-xs font-black">Meta title<input value={row.metaTitle||''} onChange={e=>updatePage(index,'metaTitle',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label><label className="text-xs font-black">Meta description<input value={row.metaDescription||''} onChange={e=>updatePage(index,'metaDescription',e.target.value)} className="mt-2 w-full rounded-xl border p-3 font-normal"/></label></div><div className="mt-4 flex gap-2"><button onClick={()=>savePage(row)} className="rounded-xl bg-slate-950 px-4 py-2.5 text-xs font-black text-white">Save</button><a href={`/pages/${row.slug}`} target="_blank" rel="noreferrer" className="rounded-xl border px-4 py-2.5 text-xs font-black">Preview</a><button onClick={()=>deletePage(row.id)} className="rounded-xl border border-rose-200 px-4 py-2.5 text-xs font-black text-rose-600">Delete</button></div></article>)}</div></section>}

    {tab==='settings'&&<section className="mt-6"><div><h2 className="text-2xl font-black">Brand, Theme & Global Settings</h2><p className="text-sm text-slate-500">The storefront reads these values at runtime.</p></div><div className="mt-5 grid gap-4 xl:grid-cols-2">{settings.map((row:any,index:number)=><article key={row.id} className="rounded-[1.5rem] border border-slate-200 bg-white p-5"><div className="flex items-center gap-3"><Settings2 size={17}/><div><p className="font-black">{row.key}</p><p className="text-xs text-slate-400">{row.groupName} · {row.description}</p></div></div><label className="mt-4 block text-xs font-black">JSON value<textarea value={JSON.stringify(row.value||{},null,2)} onChange={e=>{try{updateSetting(index,'value',JSON.parse(e.target.value))}catch{}}} className="mt-2 min-h-48 w-full rounded-xl border bg-slate-50 p-3 font-mono text-xs"/></label><button onClick={()=>saveSetting(row)} className="mt-3 flex items-center gap-2 rounded-xl bg-slate-950 px-4 py-2.5 text-xs font-black text-white"><Save size={14}/>Save setting</button></article>)}</div></section>}
  </AdminShell>
}
