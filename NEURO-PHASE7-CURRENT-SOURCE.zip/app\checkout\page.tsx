'use client';

import { FormEvent,useEffect,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Check, MapPin, ShieldCheck, Tag, Truck, WalletCards } from 'lucide-react';
import Navbar from '@/components/navbar';
import LocationPicker from '@/components/location-picker';
import CompactLocationSelector from '@/components/compact-location-selector';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

export default function CheckoutPage(){
  const router=useRouter();
  const [cart,setCart]=useState<any>(null),[addresses,setAddresses]=useState<any[]>([]),[selected,setSelected]=useState(''),[manual,setManual]=useState(false),[saveAddress,setSaveAddress]=useState(true),[error,setError]=useState(''),[busy,setBusy]=useState(false),[shippingQuote,setShippingQuote]=useState<any>({charge:120});
  const [form,setForm]=useState<any>({customerName:'',phone:'',email:'',addressLine:'',city:'',division:'',district:'',area:'',landmark:'',postalCode:'',addressLabel:'HOME',latitude:null,longitude:null,locationSource:'NONE',notes:'',paymentMode:'COD',couponCode:''});

  function applyAddress(a:any){setForm((x:any)=>({...x,customerName:a.recipientName,phone:a.phone,addressLine:a.addressLine,city:a.district,division:a.division,district:a.district,area:a.area,landmark:a.landmark||'',postalCode:a.postalCode||'',addressLabel:a.type,latitude:a.latitude===null?null:Number(a.latitude),longitude:a.longitude===null?null:Number(a.longitude),locationSource:a.locationSource||'NONE'}))}
  function useSavedAddress(a:any){setSelected(a.id);applyAddress(a);setManual(false)}
  function useNewAddress(){const u=getStoredUser();setSelected('');setManual(true);setForm((x:any)=>({...x,customerName:u?.name||'',phone:u?.phone||'',addressLine:'',city:'',division:'',district:'',area:'',landmark:'',postalCode:'',addressLabel:'HOME',latitude:null,longitude:null,locationSource:'NONE'}))}

  useEffect(()=>{
    const u=getStoredUser();if(!u){router.replace('/login');return}
    setForm((x:any)=>({...x,customerName:u.name,phone:u.phone||'',email:u.email}));
    Promise.all([api.get('/cart'),api.get('/users/me/addresses')]).then(([c,a])=>{
      if(!c.data.items.length){router.replace('/cart');return}
      setCart(c.data);const list=a.data||[];setAddresses(list);const d=list.find((x:any)=>x.isDefault);
      if(d){setSelected(d.id);applyAddress(d);setManual(false)}else setManual(true)
    }).catch(()=>setError('Could not prepare checkout.'))
  },[router]);

  useEffect(()=>{
    if(!cart||!form.district)return;
    api.get('/shipping/quote',{params:{district:form.district,area:form.area||'',subtotal:cart.subtotal}})
      .then(r=>setShippingQuote(r.data))
      .catch(()=>setShippingQuote({charge:cart.subtotal>=3000?0:120}))
  },[cart,form.district,form.area]);

  async function submit(e:FormEvent){
    e.preventDefault();setBusy(true);setError('');
    try{
      let addressId=selected||undefined;
      if(manual&&saveAddress){
        const saved=await api.post('/users/me/addresses',{recipientName:form.customerName,phone:form.phone,type:'HOME',division:form.division,district:form.district,area:form.area,addressLine:form.addressLine,landmark:form.landmark||undefined,postalCode:form.postalCode||undefined,latitude:form.latitude??undefined,longitude:form.longitude??undefined,locationSource:form.locationSource,isDefault:addresses.length===0});
        addressId=saved.data.id;
      }
      const r=await api.post('/checkout',{...form,city:form.district,addressId});
      router.push(`/account/orders/${r.data.id}`);
    }catch(err:any){const m=err?.response?.data?.message;setError(Array.isArray(m)?m.join(', '):m||'Checkout failed.')}
    finally{setBusy(false)}
  }

  if(!cart)return <main className="grid min-h-screen place-items-center bg-slate-50 font-bold">Preparing checkout...</main>;
  const shipping=Number(shippingQuote?.charge??120);
  const estimated=Number(cart.subtotal)+shipping;

  return <main className="min-h-screen text-slate-950">
    <Navbar/>
    <section className="mx-auto max-w-7xl px-5 py-8">
      <div className="flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Secure checkout</p><h1 className="mt-2 text-4xl font-black">Complete your order</h1><p className="mt-2 text-sm text-slate-500">Delivery, payment and review before placing the order.</p></div><Link href="/cart" className="text-sm font-black">← Back to cart</Link></div>
      {error&&<p className="mt-5 rounded-xl bg-rose-50 p-4 text-sm font-semibold text-rose-700">{error}</p>}

      <form onSubmit={submit} className="mt-7 grid gap-6 lg:grid-cols-[1fr_390px]">
        <section className="space-y-5">
          <div className="rounded-[1.75rem] border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex items-start gap-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1464f4] text-white"><MapPin size={18}/></span><div><p className="text-xs font-black uppercase tracking-[.15em] text-slate-400">Step 1</p><h2 className="mt-1 text-xl font-black">Delivery address</h2><p className="mt-1 text-sm text-slate-500">Choose a saved address or enter a new delivery point.</p></div></div>

            {addresses.length>0&&<div className="mt-5 grid gap-3 md:grid-cols-2">{addresses.map((a:any)=><button type="button" key={a.id} onClick={()=>useSavedAddress(a)} className={`relative rounded-2xl border p-4 text-left transition ${!manual&&selected===a.id?'border-[#1464f4] bg-slate-50 ring-1 ring-slate-950':'border-slate-200 hover:border-slate-400'}`}>
              {!manual&&selected===a.id&&<span className="absolute right-3 top-3 grid h-6 w-6 place-items-center rounded-full bg-[#1464f4] text-white"><Check size={13}/></span>}
              <div className="flex flex-wrap gap-2"><span className="rounded-full bg-slate-100 px-2 py-1 text-[10px] font-black">{a.type}</span>{a.isDefault&&<span className="rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-black text-emerald-700">DEFAULT</span>}{a.latitude&&a.longitude&&<span className="rounded-full bg-blue-50 px-2 py-1 text-[10px] font-black text-blue-700">GPS</span>}</div>
              <p className="mt-3 font-black">{a.recipientName}</p><p className="text-xs text-slate-500">{a.phone}</p><p className="mt-2 text-sm">{a.addressLine}</p><p className="mt-1 text-xs text-slate-400">{[a.area,a.district].filter(Boolean).join(', ')}</p>
            </button>)}</div>}
            <button type="button" onClick={useNewAddress} className="mt-4 rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-black">+ Use a different address</button>

            {manual&&<div className="mt-5 border-t border-slate-200 pt-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="text-sm font-black">Full name<input required value={form.customerName} onChange={e=>setForm({...form,customerName:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 font-normal outline-none"/></label>
                <label className="text-sm font-black">Phone<input required value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 font-normal outline-none"/></label>
                <div className="sm:col-span-2"><CompactLocationSelector division={form.division} district={form.district} area={form.area} postalCode={form.postalCode} onChange={(x:any)=>setForm({...form,...x,city:x.district})}/></div>
                <label className="text-sm font-black sm:col-span-2">Full address<textarea required value={form.addressLine} onChange={e=>setForm({...form,addressLine:e.target.value})} placeholder="House, road, block, floor..." className="focus-ring mt-2 min-h-24 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 font-normal outline-none"/></label>
                <label className="text-sm font-black sm:col-span-2">Landmark <span className="font-normal text-slate-400">(optional)</span><input value={form.landmark} onChange={e=>setForm({...form,landmark:e.target.value})} className="focus-ring mt-2 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 font-normal outline-none"/></label>
                <div className="sm:col-span-2"><LocationPicker latitude={form.latitude} longitude={form.longitude} locationSource={form.locationSource} onChange={(latitude,longitude,locationSource)=>setForm({...form,latitude,longitude,locationSource})}/></div>
              </div>
              <label className="mt-4 flex items-center gap-3 rounded-xl bg-slate-50 p-4 text-sm font-black"><input type="checkbox" checked={saveAddress} onChange={e=>setSaveAddress(e.target.checked)}/>Save this address to my account</label>
            </div>}
          </div>

          <div className="rounded-[1.75rem] border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex items-start gap-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1464f4] text-white"><WalletCards size={18}/></span><div><p className="text-xs font-black uppercase tracking-[.15em] text-slate-400">Step 2</p><h2 className="mt-1 text-xl font-black">Payment</h2><p className="mt-1 text-sm text-slate-500">Choose how you want to pay.</p></div></div>
            <div className="mt-5 grid gap-3">
              {[['COD','Cash on delivery','Pay when your order arrives.'],['FULL_ONLINE','Online payment','Gateway-ready online payment flow.'],['PARTIAL','Partial payment','Pay a portion online, remaining later.']].map(([v,l,s])=><label key={v} className={`flex cursor-pointer gap-4 rounded-2xl border p-4 ${form.paymentMode===v?'border-[#1464f4] bg-slate-50':'border-slate-200'}`}><input type="radio" name="payment" value={v} checked={form.paymentMode===v} onChange={e=>setForm({...form,paymentMode:e.target.value})}/><div><p className="font-black">{l}</p><p className="mt-1 text-xs text-slate-500">{s}</p></div></label>)}
            </div>
          </div>

          <div className="rounded-[1.75rem] border border-slate-200 bg-white p-5 sm:p-6">
            <div className="flex items-start gap-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[#1464f4] text-white"><Tag size={18}/></span><div><p className="text-xs font-black uppercase tracking-[.15em] text-slate-400">Step 3</p><h2 className="mt-1 text-xl font-black">Coupon & note</h2></div></div>
            <input value={form.couponCode} onChange={e=>setForm({...form,couponCode:e.target.value.toUpperCase()})} placeholder="Coupon code" className="focus-ring mt-5 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 uppercase outline-none"/>
            <textarea value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Optional order note..." className="focus-ring mt-3 min-h-20 w-full rounded-xl border border-slate-200 bg-slate-50 p-3.5 outline-none"/>
          </div>
        </section>

        <aside className="h-fit rounded-[1.75rem] bg-[#1464f4] p-6 text-white premium-shadow lg:sticky lg:top-28">
          <p className="text-xs font-black uppercase tracking-[.16em] text-white/40">Order summary</p>
          <div className="mt-5 space-y-4">{cart.items.map((x:any)=><div key={x.id} className="flex justify-between gap-4 text-sm"><div><p className="font-bold">{x.productName}</p><p className="mt-1 text-xs text-white/40">Qty {x.quantity}</p></div><span className="font-black">BDT {x.lineTotal}</span></div>)}</div>
          <div className="mt-6 space-y-3 border-t border-white/10 pt-5 text-sm"><div className="flex justify-between text-white/55"><span>Subtotal</span><span className="text-white">BDT {cart.subtotal}</span></div><div className="flex justify-between text-white/55"><span>Shipping</span><span className="text-white">{shipping===0?'FREE':`BDT ${shipping}`}</span></div><div className="flex justify-between border-t border-white/10 pt-4 text-lg font-black"><span>Estimated total</span><span>BDT {estimated}</span></div></div>
          {shippingQuote?.freeShippingThreshold&&shipping>0&&<div className="mt-4 flex gap-3 rounded-2xl bg-white/5 p-4"><Truck size={18} className="shrink-0"/><p className="text-xs leading-5 text-white/50">Free shipping starts at BDT {shippingQuote.freeShippingThreshold} for this zone.</p></div>}
          <div className="mt-4 flex gap-3 rounded-2xl bg-white/5 p-4"><ShieldCheck size={18} className="shrink-0"/><p className="text-xs leading-5 text-white/50">By placing the order, delivery address and payment choice are securely recorded with your order.</p></div>
          <button disabled={busy||(!selected&&!manual)} className="mt-5 w-full rounded-xl bg-white py-3.5 text-sm font-black text-slate-950 disabled:opacity-40">{busy?'Placing order...':'Place order securely'}</button>
        </aside>
      </form>
    </section>
    <StoreFooter/>
  </main>
}
