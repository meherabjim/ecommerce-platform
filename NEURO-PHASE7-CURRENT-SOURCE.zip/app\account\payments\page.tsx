'use client';

import { useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import { CreditCard } from 'lucide-react';
import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const money=(v:any)=>`BDT ${Number(v||0).toLocaleString(undefined,{maximumFractionDigits:2})}`;
const pretty=(v:string)=>String(v||'').replaceAll('_',' ');

export default function AccountPayments(){
  const router=useRouter();const [items,setItems]=useState<any[]>([]);
  useEffect(()=>{if(!getStoredUser()){router.replace('/login');return}api.get('/payments/me').then(r=>setItems(r.data||[]))},[router]);
  return <main className="min-h-screen text-slate-950"><Navbar/><AccountShell>
    <div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Account finance</p><h1 className="mt-2 text-4xl font-black">Payment history</h1><p className="mt-2 text-sm text-slate-500">Verified, pending and due-collection transactions linked to your orders.</p></div>
    <div className="mt-6 space-y-3">{items.map(x=><article key={x.id} className="flex flex-wrap items-center gap-4 rounded-2xl border border-slate-200 bg-white p-5"><span className="grid h-11 w-11 place-items-center rounded-xl bg-[#1464f4] text-white"><CreditCard size={18}/></span><div className="min-w-[220px] flex-1"><p className="font-black">{pretty(x.type)}</p><p className="mt-1 font-mono text-[10px] text-slate-400">{x.orderId}</p><p className="mt-1 text-xs text-slate-500">{x.provider} · {x.paymentMethod||'—'}</p></div><div className="text-right"><p className="text-lg font-black">{money(x.amount)}</p><p className="mt-1 text-xs font-black">{pretty(x.status)}</p></div></article>)}</div>
    {!items.length&&<div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center text-slate-500">No payment history yet.</div>}
  </AccountShell><StoreFooter/></main>
}
