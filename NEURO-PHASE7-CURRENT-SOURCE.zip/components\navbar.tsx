'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Bell, ChevronDown, Heart, Menu, PackageSearch, Search, ShoppingCart, UserRound, X } from 'lucide-react';
import { api } from '@/lib/api';
import { AuthUser, clearAuth, getStoredUser, isStaffRole } from '@/lib/auth';
import { useStoreConfig } from '@/components/store-config-provider';
import { Language, useI18n } from '@/lib/i18n';
import { localizedCategoryName, localizedProductName } from '@/lib/localized';
import { getGuestCart } from '@/lib/guest-cart';

export default function Navbar(){
  const router=useRouter();
  const config=useStoreConfig();
  const {language,setLanguage,t}=useI18n();
  const identity=config['store.identity']||{};
  const commerce=config['store.commerce']||{};
  const [user,setUser]=useState<AuthUser|null>(null);
  const [ready,setReady]=useState(false);
  const [unread,setUnread]=useState(0);
  const [open,setOpen]=useState(false);
  const [categoryOpen,setCategoryOpen]=useState(false);
  const [categories,setCategories]=useState<any[]>([]);
  const [products,setProducts]=useState<any[]>([]);
  const [query,setQuery]=useState('');
  const [searchFocused,setSearchFocused]=useState(false);
  const [cartCount,setCartCount]=useState(0);

  const storeName=identity.storeName||'Neuro Commerce';
  const tagline=identity.tagline||'Smart shopping, made simple';
  const logoUrl=identity.logoUrl||'';
  const announcement=commerce.freeShippingMessage||'Fast delivery • Secure checkout • Easy returns';
  const supportPhone=identity.supportPhone||identity.phone||'';

  useEffect(()=>{
    const current=getStoredUser();
    const refreshCartCount=()=>{
      const now=getStoredUser();
      if(!now){setCartCount(getGuestCart().reduce((sum,x)=>sum+x.quantity,0));return;}
      api.get('/cart').then(r=>setCartCount(Number(r.data?.itemCount||0))).catch(()=>setCartCount(0));
    };
    refreshCartCount();
    window.addEventListener('guest-cart-updated',refreshCartCount as EventListener);
    window.addEventListener('cart-updated',refreshCartCount as EventListener);
    setUser(current);setReady(true);
    Promise.all([api.get('/catalog/public/categories'),api.get('/catalog/public/products')]).then(([c,p])=>{setCategories(c.data||[]);setProducts(p.data||[])}).catch(()=>{});
    if(current){api.get('/notifications').then(r=>setUnread((r.data||[]).filter((x:any)=>!x.isRead).length)).catch(()=>{});}
    return ()=>{window.removeEventListener('guest-cart-updated',refreshCartCount as EventListener);window.removeEventListener('cart-updated',refreshCartCount as EventListener)};
  },[]);

  const accountHref=useMemo(()=>{
    if(!user)return '/login';
    if(isStaffRole(user.role))return '/admin';
    if(user.role==='DELIVERY_AGENT')return '/delivery';
    return '/account';
  },[user]);

  const suggestions=useMemo(()=>{
    const q=query.trim().toLowerCase();
    if(q.length<2)return [];
    return products.filter((p:any)=>[p.name,p.nameBn,p.brand?.name,p.category?.name,p.category?.nameBn].filter(Boolean).join(' ').toLowerCase().includes(q)).slice(0,6);
  },[products,query]);

  function logout(){clearAuth();setUser(null);setOpen(false);router.replace('/login');router.refresh();}
  function search(e:FormEvent){e.preventDefault();const q=query.trim();router.push(q?`/shop?q=${encodeURIComponent(q)}`:'/shop');setOpen(false);}

  return <>
    <div className="border-b border-slate-200 bg-[#f7f9fc] text-slate-600">
      <div className="mx-auto flex min-h-9 max-w-7xl items-center justify-between gap-3 px-4 text-[11px] sm:px-5">
        <div className="hidden items-center gap-4 sm:flex">
          <span>{announcement}</span>
          {supportPhone&&<a href={`tel:${supportPhone}`} className="font-bold text-slate-700">{t('support')}: {supportPhone}</a>}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Link href="/track-order" className="hidden font-bold hover:text-[#1464f4] sm:inline">{t('track')}</Link>
          <span className="hidden h-4 w-px bg-slate-300 sm:block"/>
          <span className="font-semibold">{t('language')}:</span>
          {(['bn','en'] as Language[]).map(code=><button key={code} onClick={()=>setLanguage(code)} className={`rounded px-2 py-1 font-black transition ${language===code?'bg-[#1464f4] text-white':'hover:bg-white hover:text-[#1464f4]'}`}>{code==='bn'?'বাংলা':'ENG'}</button>)}
        </div>
      </div>
    </div>

    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 shadow-sm backdrop-blur-xl">
      <div className="mx-auto flex min-h-[76px] max-w-7xl items-center gap-3 px-4 sm:px-5">
        <Link href="/" className="flex shrink-0 items-center gap-3">
          {logoUrl?<img src={logoUrl} alt={storeName} className="h-11 w-11 rounded-xl object-cover"/>:<span className="grid h-11 w-11 place-items-center rounded-xl bg-[#1464f4] text-lg font-black text-white">{storeName.charAt(0).toUpperCase()}</span>}
          <div className="hidden sm:block"><p className="text-lg font-black leading-none text-slate-900">{storeName}</p><p className="mt-1 text-[9px] font-bold uppercase tracking-[.16em] text-slate-400">{tagline}</p></div>
        </Link>

        <div className="relative hidden lg:block">
          <button onClick={()=>setCategoryOpen(v=>!v)} className="flex h-11 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-4 text-sm font-black text-slate-700 hover:border-[#1464f4] hover:text-[#1464f4]">{t('categories')}<ChevronDown size={15}/></button>
          {categoryOpen&&<div className="absolute left-0 top-13 w-[min(720px,90vw)] overflow-hidden rounded-2xl border border-slate-200 bg-white p-4 shadow-2xl"><div className="flex items-center justify-between border-b border-slate-100 pb-3"><div><p className="text-xs font-black uppercase tracking-[.14em] text-blue-600">{language==='bn'?'ক্যাটাগরি':'Categories'}</p><p className="mt-1 text-sm text-slate-500">{language==='bn'?'দ্রুত আপনার প্রয়োজনের পণ্য খুঁজুন':'Browse the catalog faster'}</p></div><Link href="/shop" onClick={()=>setCategoryOpen(false)} className="text-xs font-black text-[#1464f4]">{t('allCategories')} →</Link></div><div className="mt-3 grid gap-1 sm:grid-cols-2 lg:grid-cols-3">{categories.map(c=><Link key={c.id} href={`/shop?category=${encodeURIComponent(c.id)}`} onClick={()=>setCategoryOpen(false)} className="rounded-xl px-3 py-3 text-sm font-bold text-slate-700 hover:bg-blue-50 hover:text-[#1464f4]">{localizedCategoryName(language,c)}</Link>)}</div></div>}
        </div>

        <form onSubmit={search} className="relative ml-auto hidden min-w-0 max-w-xl flex-1 md:flex">
          <div className="flex w-full overflow-hidden rounded-xl border-2 border-[#1464f4] bg-white">
            <input value={query} onFocus={()=>setSearchFocused(true)} onBlur={()=>setTimeout(()=>setSearchFocused(false),150)} onChange={e=>setQuery(e.target.value)} className="min-w-0 flex-1 px-4 py-2.5 text-sm outline-none" placeholder={t('search')}/>
            <button className="grid w-12 place-items-center bg-[#1464f4] text-white"><Search size={19}/></button>
          </div>
          {searchFocused&&suggestions.length>0&&<div className="absolute left-0 right-0 top-[50px] overflow-hidden rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl">{suggestions.map((p:any)=>{const image=p.variants?.[0]?.imageUrl||(Array.isArray(p.media)?p.media.find((m:any)=>m.type==='image')?.url:null)||p.primaryImageUrl;return <Link key={p.id} href={`/shop/${p.slug}`} onMouseDown={e=>e.preventDefault()} onClick={()=>{setSearchFocused(false);setQuery('')}} className="flex items-center gap-3 rounded-xl p-2.5 hover:bg-blue-50">{image?<img src={image} alt="" className="h-11 w-11 rounded-lg object-cover"/>:<span className="grid h-11 w-11 place-items-center rounded-lg bg-slate-100 text-slate-400"><PackageSearch size={18}/></span>}<div className="min-w-0"><p className="truncate text-sm font-black text-slate-800">{localizedProductName(language,p)}</p><p className="mt-0.5 truncate text-[11px] text-slate-400">{p.category?localizedCategoryName(language,p.category):''}{p.brand?.name?` · ${p.brand.name}`:''}</p></div></Link>})}<button type="submit" className="mt-1 w-full rounded-xl bg-slate-50 px-3 py-2.5 text-left text-xs font-black text-[#1464f4]">{language==='bn'?`"${query}" এর সব ফলাফল দেখুন`:`See all results for "${query}"`} →</button></div>}
        </form>

        <nav className="hidden items-center gap-4 text-sm font-bold text-slate-600 xl:flex">
          <Link href="/shop?sort=new" className="hover:text-[#1464f4]">{t('newArrivals')}</Link>
          <Link href="/shop?offers=1" className="text-[#f36b21] hover:text-[#d95312]">{t('offers')}</Link>
        </nav>

        <div className="flex items-center gap-1.5">
          {ready&&user&&<Link href="/account/wishlist" title={t('wishlist')} className="hidden h-10 w-10 place-items-center rounded-xl text-slate-600 hover:bg-blue-50 hover:text-[#1464f4] sm:grid"><Heart size={20}/></Link>}
          {ready&&user&&<Link href="/account/notifications" title={t('notifications')} className="relative hidden h-10 w-10 place-items-center rounded-xl text-slate-600 hover:bg-blue-50 hover:text-[#1464f4] sm:grid"><Bell size={20}/>{unread>0&&<span className="absolute right-0 top-0 grid min-h-4 min-w-4 place-items-center rounded-full bg-[#f36b21] px-1 text-[9px] font-black text-white">{unread>9?'9+':unread}</span>}</Link>}
          <Link href={accountHref} className="flex h-10 items-center gap-2 rounded-xl px-2 text-slate-700 hover:bg-blue-50 hover:text-[#1464f4]" title={t('account')}><UserRound size={21}/><span className="hidden max-w-24 truncate text-xs font-black 2xl:block">{user?.name||t('login')}</span></Link>
          <Link href="/cart" title={t('cart')} className="relative grid h-10 w-10 place-items-center rounded-xl bg-[#f36b21] text-white shadow-sm hover:bg-[#df5d18]"><ShoppingCart size={20}/>{cartCount>0&&<span className="absolute -right-1 -top-1 grid min-h-5 min-w-5 place-items-center rounded-full bg-[#1464f4] px-1 text-[10px] font-black text-white">{cartCount>99?'99+':cartCount}</span>}</Link>
          <button onClick={()=>setOpen(v=>!v)} className="grid h-10 w-10 place-items-center rounded-xl border border-slate-200 lg:hidden">{open?<X size={20}/>:<Menu size={20}/>}</button>
        </div>
      </div>

      <div className="hidden border-t border-slate-100 bg-white lg:block">
        <div className="mx-auto flex max-w-7xl items-center gap-7 px-5 py-2.5 text-[13px] font-black text-slate-600">
          <Link href="/" className="hover:text-[#1464f4]">{t('home')}</Link>
          <Link href="/shop" className="hover:text-[#1464f4]">{t('shop')}</Link>
          <Link href="/shop?sort=new" className="hover:text-[#1464f4]">{t('newArrivals')}</Link>
          <Link href="/shop?offers=1" className="text-[#f36b21] hover:text-[#d95312]">{t('offers')}</Link>
          <Link href="/track-order" className="hover:text-[#1464f4]">{t('track')}</Link>
          <Link href="/pages/about" className="hover:text-[#1464f4]">{t('about')}</Link>
          <Link href="/pages/contact" className="hover:text-[#1464f4]">{t('contact')}</Link>
        </div>
      </div>

      {open&&<div className="border-t border-slate-200 bg-white px-4 py-4 lg:hidden">
        <form onSubmit={search} className="mb-3 flex overflow-hidden rounded-xl border-2 border-[#1464f4]"><input value={query} onChange={e=>setQuery(e.target.value)} className="min-w-0 flex-1 px-3 py-2.5 text-sm outline-none" placeholder={t('search')}/><button className="w-11 bg-[#1464f4] text-white"><Search className="mx-auto" size={18}/></button></form>
        <div className="grid gap-1 text-sm font-bold text-slate-700">
          <Link onClick={()=>setOpen(false)} href="/">{t('home')}</Link>
          <Link onClick={()=>setOpen(false)} href="/shop" className="rounded-lg py-2">{t('shop')}</Link>
          {categories.slice(0,8).map(c=><Link key={c.id} onClick={()=>setOpen(false)} href={`/shop?category=${c.id}`} className="rounded-lg py-2 text-slate-500">{localizedCategoryName(language,c)}</Link>)}
          <Link onClick={()=>setOpen(false)} href="/track-order" className="rounded-lg py-2">{t('track')}</Link>
          <Link onClick={()=>setOpen(false)} href={accountHref} className="rounded-lg py-2">{t('account')}</Link>
          {user&&<button onClick={logout} className="rounded-lg py-2 text-left text-rose-600">{t('logout')}</button>}
        </div>
      </div>}
    </header>
  </>
}
