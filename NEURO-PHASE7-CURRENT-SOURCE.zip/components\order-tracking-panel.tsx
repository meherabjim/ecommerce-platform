'use client';


const lifecycle = [
  'CONFIRMED',
  'PROCESSING',
  'PACKED',
  'READY_FOR_PICKUP',
  'SHIPPED',
  'IN_TRANSIT',
  'OUT_FOR_DELIVERY',
  'DELIVERED',
];


function nice(
  value:string,
) {

  return String(
    value || '',
  )
    .replaceAll('_',' ')
    .toLowerCase()
    .replace(
      /\b\w/g,
      value =>
        value.toUpperCase(),
    );
}


export default function OrderTrackingPanel({
  order,
}:{
  order:any;
}) {

  if(!order){
    return null;
  }


  const currentIndex =
    lifecycle.indexOf(
      order.status,
    );


  const hasGPS =
    order.deliveryLatitude !==
      null &&
    order.deliveryLatitude !==
      undefined &&
    order.deliveryLongitude !==
      null &&
    order.deliveryLongitude !==
      undefined;


  const address =
    [
      order.addressLine,
      order.area,
      order.district ||
        order.city,
      order.division,
    ]
      .filter(Boolean)
      .join(', ');


  return (
    <section className="mt-5 rounded-2xl border border-slate-200 bg-white p-5">

      <div className="flex flex-wrap items-center justify-between gap-3">

        <div>

          <p className="text-xs font-bold uppercase tracking-[0.14em] text-slate-400">
            Delivery tracking
          </p>

          <h2 className="mt-1 text-xl font-black">
            {nice(order.status)}
          </h2>

          {order.trackingNumber && (
            <p className="mt-1 text-xs text-slate-500">
              Tracking ID:
              {' '}
              <b>
                {order.trackingNumber}
              </b>
            </p>
          )}

        </div>


        <span className="rounded-full bg-[#1464f4] px-3 py-1.5 text-xs font-bold text-white">
          {nice(order.status)}
        </span>

      </div>


      {![
        'CANCELLED',
        'DELIVERY_FAILED',
      ].includes(
        order.status,
      ) && (

        <div className="mt-5 overflow-x-auto">

          <div className="flex min-w-[720px] items-start">

            {lifecycle.map(
              (status,index) => {

                const complete =
                  currentIndex >=
                  index;

                return (
                  <div
                    key={status}
                    className="relative flex flex-1 flex-col items-center"
                  >

                    {index > 0 && (
                      <div
                        className={`absolute right-1/2 top-[8px] h-[2px] w-full ${
                          complete
                            ? 'bg-[#1464f4]'
                            : 'bg-slate-200'
                        }`}
                      />
                    )}

                    <div
                      className={`relative z-10 h-4 w-4 rounded-full border-[3px] ${
                        complete
                          ? 'border-[#1464f4] bg-[#1464f4]'
                          : 'border-slate-200 bg-white'
                      }`}
                    />

                    <p className="mt-2 max-w-[80px] text-center text-[10px] font-bold leading-tight">
                      {nice(status)}
                    </p>

                  </div>
                );
              },
            )}

          </div>

        </div>
      )}


      {order.status ===
        'DELIVERY_FAILED' && (

        <div className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">

          <b>
            Delivery attempt failed.
          </b>

          {order.deliveryFailureReason && (
            <span>
              {' '}
              {order.deliveryFailureReason}
            </span>
          )}

        </div>
      )}


      <div className="mt-5 grid gap-3 md:grid-cols-2">

        <div className="rounded-xl bg-slate-50 p-4">

          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
            Delivery address
          </p>

          <p className="mt-2 font-black">
            {order.customerName}
          </p>

          <p className="text-sm text-slate-600">
            {order.phone}
          </p>

          <p className="mt-2 text-sm text-slate-600">
            {address}
          </p>


          {hasGPS && (
            <a
              href={`https://www.google.com/maps?q=${order.deliveryLatitude},${order.deliveryLongitude}`}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-flex rounded-lg border bg-white px-3 py-2 text-xs font-bold"
            >
              View location
            </a>
          )}

        </div>


        <div className="rounded-xl bg-slate-50 p-4">

          <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-slate-400">
            Delivery & payment
          </p>


          {order.deliveryAgent ? (

            <>
              <p className="mt-2 font-black">
                {order.deliveryAgent.name}
              </p>

              <p className="text-sm text-slate-600">
                {order.deliveryAgent.phone ||
                  'No phone'}
              </p>

              {order.deliveryAgent.phone && (
                <a
                  href={`tel:${order.deliveryAgent.phone}`}
                  className="mt-3 inline-flex rounded-lg bg-[#1464f4] px-3 py-2 text-xs font-bold text-white"
                >
                  Call rider
                </a>
              )}
            </>

          ) : (

            <p className="mt-2 text-sm text-slate-500">
              Rider not assigned yet.
            </p>
          )}


          <div className="mt-3 border-t pt-3 text-xs">

            <div className="flex justify-between gap-3">

              <span className="text-slate-500">
                Payment
              </span>

              <b>
                {order.paymentMode}
                {' / '}
                {order.paymentStatus}
              </b>

            </div>


            {order.codCollected !==
              null &&
              order.codCollected !==
              undefined && (

              <div className="mt-2 flex justify-between">

                <span className="text-slate-500">
                  COD collected
                </span>

                <b>
                  BDT {order.codCollected}
                </b>

              </div>
            )}

          </div>

        </div>

      </div>

    </section>
  );
}
