'use client';

import { useEffect,useMemo,useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Bell, ChevronRight, Heart, MapPin, PackageCheck, RotateCcw, Truck } from 'lucide-react';
import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const pretty=(x:string)=>String(x||'').replaceAll('_',' ');

export default function AccountPage(){
  const router=useRouter();
  const [user,setUser]=useState<any>(null),[orders,setOrders]=useState<any[]>([]),[notifications,setNotifications]=useState<any[]>([]),[wishlist,setWishlist]=useState<any[]>([]);
  useEffect(()=>{
    const current=getStoredUser();if(!current){router.replace('/login');return}
    setUser(current);
    Promise.all([api.get('/me/orders'),api.get('/notifications'),api.get('/wishlist')]).then(([o,n,w])=>{setOrders(o.data||[]);setNotifications(n.data||[]);setWishlist(w.data||[])})
  },[router]);

  const stats=useMemo(()=>({
    active:orders.filter(o=>!['DELIVERED','CANCELLED'].includes(o.status)).length,
    delivered:orders.filter(o=>o.status==='DELIVERED').length,
    unread:notifications.filter(x=>!x.isRead).length,
  }),[orders,notifications]);

  if(!user)return null;
  return (
    <main className="min-h-screen text-slate-950">
      <Navbar/>
      <AccountShell>
        <section className="overflow-hidden rounded-[2rem] bg-[#1464f4] p-7 text-white premium-shadow sm:p-9">
          <p className="text-xs font-black uppercase tracking-[.18em] text-white/40">Customer portal</p>
          <div className="mt-3 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div><h1 className="text-4xl font-black tracking-tight">Welcome back, {user.name.split(' ')[0]}.</h1><p className="mt-2 text-sm text-white/50">{user.email}{user.phone?` · ${user.phone}`:''}</p></div>
            <Link href="/shop" className="w-fit rounded-xl bg-white px-5 py-3 text-sm font-black text-slate-950">Continue shopping</Link>
          </div>
        </section>

        <section className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {[
            ['Orders',orders.length,PackageCheck,'/account'],
            ['Active delivery',stats.active,Truck,'/account'],
            ['Wishlist',wishlist.length,Heart,'/account/wishlist'],
            ['Notifications',stats.unread,Bell,'/account/notifications']
          ].map(([label,value,Icon,href]:any)=><Link key={label} href={href} className="premium-card rounded-2xl p-5 transition hover:-translate-y-0.5">
            <div className="flex items-center justify-between"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#1464f4] text-white"><Icon size={17}/></span><ChevronRight size={16} className="text-slate-300"/></div>
            <p className="mt-5 text-3xl font-black">{value}</p><p className="mt-1 text-sm font-semibold text-slate-500">{label}</p>
          </Link>)}
        </section>

        <section className="mt-5 grid gap-3 md:grid-cols-2">
          <Link href="/account/addresses" className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center gap-3"><MapPin size={18}/><div><p className="font-black">Saved addresses</p><p className="text-xs text-slate-500">Manage home, office and GPS delivery points.</p></div></div><ChevronRight size={17}/></Link>
          <Link href="/account/returns" className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-5"><div className="flex items-center gap-3"><RotateCcw size={18}/><div><p className="font-black">Returns & refunds</p><p className="text-xs text-slate-500">See submitted return requests and status.</p></div></div><ChevronRight size={17}/></Link>
        </section>

        <section className="mt-5 rounded-[1.75rem] border border-slate-200 bg-white p-5 sm:p-6">
          <div className="flex items-end justify-between gap-4"><div><p className="text-xs font-black uppercase tracking-[.16em] text-slate-400">Recent activity</p><h2 className="mt-2 text-2xl font-black">Your orders</h2></div><span className="text-sm font-bold text-slate-400">{stats.delivered} delivered</span></div>
          <div className="mt-5 space-y-3">
            {orders.map(o=><Link key={o.id} href={`/account/orders/${o.id}`} className="grid gap-3 rounded-2xl border border-slate-200 bg-slate-50 p-4 transition hover:border-slate-300 hover:bg-white md:grid-cols-[1.4fr_.8fr_.8fr_.7fr] md:items-center">
              <div><p className="font-black">{o.orderNumber}</p><p className="mt-1 text-xs text-slate-400">{o.customerName||user.name}</p></div>
              <div><p className="text-[10px] font-black uppercase text-slate-400">Status</p><p className="mt-1 text-sm font-black">{pretty(o.status)}</p></div>
              <div><p className="text-[10px] font-black uppercase text-slate-400">Payment</p><p className="mt-1 text-sm font-black">{pretty(o.paymentStatus)}</p></div>
              <p className="font-black md:text-right">BDT {o.total}</p>
            </Link>)}
            {!orders.length&&<div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center"><p className="font-black">No orders yet</p><Link href="/shop" className="mt-3 inline-block text-sm font-black underline">Start shopping</Link></div>}
          </div>
        </section>
      </AccountShell>
      <StoreFooter/>
    </main>
  )
}
