'use client';
import { FormEvent,useEffect,useState } from 'react';
import { useRouter } from 'next/navigation';
import Navbar from '@/components/navbar';
import AccountShell from '@/components/account-shell';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';
import { getStoredUser,saveAuth } from '@/lib/auth';

export default function ProfilePage(){
 const router=useRouter();const [f,setF]=useState({name:'',email:'',phone:''});const [m,setM]=useState('');
 useEffect(()=>{const u=getStoredUser();if(!u){router.replace('/login');return}setF({name:u.name||'',email:u.email||'',phone:u.phone||''})},[router]);
 async function submit(e:FormEvent){e.preventDefault();try{const r=await api.patch('/users/me/profile',f);const a=localStorage.getItem('accessToken');const rt=localStorage.getItem('refreshToken')||undefined;if(a)saveAuth(a,r.data,rt);setM('Profile updated successfully.')}catch(e:any){setM(e?.response?.data?.message||'Profile update failed.')}}
 return <main className="min-h-screen"><Navbar/><AccountShell><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Account</p><h1 className="mt-2 text-4xl font-black">Profile</h1>{m&&<p className="mt-5 rounded-xl border bg-white p-4 text-sm">{m}</p>}<form onSubmit={submit} className="mt-6 max-w-2xl rounded-[1.5rem] border bg-white p-6">{[['name','Name'],['email','Email'],['phone','Phone']].map(([k,l])=><label key={k} className="mt-4 block text-sm font-black">{l}<input value={(f as any)[k]} onChange={e=>setF({...f,[k]:e.target.value})} className="mt-2 w-full rounded-xl border p-3.5 font-normal"/></label>)}<button className="mt-5 rounded-xl bg-[#1464f4] px-5 py-3 text-sm font-black text-white">Save profile</button></form></AccountShell><StoreFooter/></main>
}
