'use client';

import { useEffect,useState } from 'react';
import { useParams } from 'next/navigation';
import Navbar from '@/components/navbar';
import StoreFooter from '@/components/store-footer';
import { api } from '@/lib/api';

export default function CmsPublicPage(){
  const {slug}=useParams<{slug:string}>();
  const [page,setPage]=useState<any>(null);
  const [error,setError]=useState(false);

  useEffect(()=>{
    if(!slug)return;
    api.get(`/cms/public/pages/${slug}`).then(r=>setPage(r.data)).catch(()=>setError(true));
  },[slug]);

  return <main className="min-h-screen text-slate-950"><Navbar/>
    <article className="mx-auto max-w-4xl px-5 py-12">
      {error?<div className="rounded-3xl border border-dashed p-12 text-center"><h1 className="text-3xl font-black">Page not found</h1></div>:
      !page?<p className="py-20 text-center font-black">Loading page...</p>:
      <><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Information</p><h1 className="mt-2 text-4xl font-black tracking-tight">{page.title}</h1><div className="mt-8 whitespace-pre-wrap rounded-[1.5rem] border border-slate-200 bg-white p-6 text-sm leading-8 text-slate-600">{page.body}</div></>}
    </article>
    <StoreFooter/>
  </main>
}
