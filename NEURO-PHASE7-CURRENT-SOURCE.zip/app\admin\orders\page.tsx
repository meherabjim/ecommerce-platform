'use client';

import { useEffect,useMemo,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ChevronRight, Search } from 'lucide-react';
import AdminShell from '@/components/admin-shell';
import { api } from '@/lib/api';
import { getStoredUser } from '@/lib/auth';

const transitions:Record<string,string[]> = {
  PENDING:['CONFIRMED','CANCELLED'],
  CONFIRMED:['PROCESSING','CANCELLED'],
  PROCESSING:['PACKED','CANCELLED'],
  PACKED:['READY_FOR_PICKUP','SHIPPED','CANCELLED'],
  READY_FOR_PICKUP:['SHIPPED','CANCELLED'],
  SHIPPED:['IN_TRANSIT','OUT_FOR_DELIVERY','DELIVERED','CANCELLED'],
  IN_TRANSIT:['OUT_FOR_DELIVERY','DELIVERED'],
  OUT_FOR_DELIVERY:['DELIVERED','DELIVERY_FAILED'],
  DELIVERY_FAILED:['OUT_FOR_DELIVERY','CANCELLED'],
  DELIVERED:[],
  CANCELLED:[],
};

const pretty=(x:string)=>String(x||'').replaceAll('_',' ');

export default function AdminOrders(){
  const router=useRouter();
  const [orders,setOrders]=useState<any[]>([]);
  const [query,setQuery]=useState('');
  const [filter,setFilter]=useState('');
  const [message,setMessage]=useState('');

  async function load(){setOrders((await api.get('/admin/orders')).data||[])}
  useEffect(()=>{const u=getStoredUser();if(!u||!['SUPER_ADMIN','ADMIN','ORDER_MANAGER','CUSTOMER_SUPPORT','FINANCE'].includes(String(u.role).toUpperCase())){router.replace('/admin?denied=1');return}load()},[router]);

  async function update(id:string,status:string){
    try{
      await api.patch(`/admin/orders/${id}/status`,{status,note:`Status changed to ${status} by admin`});
      setMessage(`Order moved to ${pretty(status)}.`);await load();
    }catch(e:any){setMessage(e?.response?.data?.message||'Update failed.')}
  }

  const visible=useMemo(()=>orders.filter((o:any)=>{
    const hay=`${o.orderNumber} ${o.customerName} ${o.phone} ${o.city} ${o.area||''}`.toLowerCase();
    return hay.includes(query.toLowerCase())&&(!filter||o.status===filter);
  }),[orders,query,filter]);

  const counts=useMemo(()=>({
    active:orders.filter((o:any)=>!['DELIVERED','CANCELLED'].includes(o.status)).length,
    delivered:orders.filter((o:any)=>o.status==='DELIVERED').length,
    cod:orders.filter((o:any)=>o.paymentMode==='COD'&&o.paymentStatus!=='PAID').length,
  }),[orders]);

  return <AdminShell>
    <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
      <div><p className="text-xs font-black uppercase tracking-[.18em] text-slate-400">Fulfillment center</p><h1 className="mt-2 text-4xl font-black tracking-tight tracking-tight">Orders</h1><p className="mt-2 text-sm text-slate-500">Search, review, fulfill and hand orders into delivery.</p></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4"><Search size={16} className="text-slate-400"/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search order/customer..." className="w-full bg-transparent py-3 text-sm outline-none"/></label>
        <select value={filter} onChange={e=>setFilter(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold"><option value="">All statuses</option>{Object.keys(transitions).map(s=><option key={s} value={s}>{pretty(s)}</option>)}</select>
      </div>
    </div>

    <section className="mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {[['Total orders',orders.length],['Active',counts.active],['Delivered',counts.delivered],['COD pending',counts.cod]].map(([a,b])=><div key={String(a)} className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-sm font-semibold text-slate-500">{a}</p><p className="mt-2 text-3xl font-black">{b}</p></div>)}
    </section>

    {message&&<p className="mt-5 rounded-2xl border border-slate-200 bg-white p-4 text-sm font-semibold">{message}</p>}

    <section className="mt-6 space-y-3">
      {visible.map((o:any)=><article key={o.id} className="overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white transition hover:shadow-lg">
        <div className="grid gap-5 p-5 md:grid-cols-[1.25fr_.7fr_.6fr_auto] md:items-center">
          <div><div className="flex flex-wrap items-center gap-2"><p className="text-lg font-black">{o.orderNumber}</p><span className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-black uppercase">{pretty(o.status)}</span></div><p className="mt-1 text-sm text-slate-500">{o.customerName} Â· {o.phone}</p><p className="mt-1 text-xs text-slate-400">{[o.area,o.district||o.city].filter(Boolean).join(', ')}</p></div>
          <div><p className="text-[10px] font-black uppercase tracking-wider text-slate-400">Payment</p><p className="mt-1 text-sm font-black">{o.paymentMode} / {pretty(o.paymentStatus)}</p></div>
          <div><p className="text-[10px] font-black uppercase tracking-wider text-slate-400">Total</p><p className="mt-1 text-xl font-black">BDT {o.total}</p></div>
          <Link href={`/admin/orders/${o.id}`} className="flex h-11 items-center justify-center gap-2 rounded-xl bg-[#1464f4] px-4 text-sm font-black text-white">Details <ChevronRight size={15}/></Link>
        </div>
        {(transitions[o.status]||[]).length>0&&<div className="flex flex-wrap items-center gap-2 border-t border-slate-100 bg-slate-50/80 px-5 py-3">
          <span className="mr-1 text-[10px] font-black uppercase tracking-wider text-slate-400">Quick actions</span>
          {(transitions[o.status]||[]).map(s=><button key={s} onClick={()=>update(o.id,s)} className={`rounded-lg border px-3 py-2 text-[11px] font-black ${s==='CANCELLED'?'border-rose-200 bg-white text-rose-600':'border-slate-200 bg-white hover:border-[#1464f4]'}`}>{pretty(s)}</button>)}
        </div>}
      </article>)}
      {!visible.length&&<div className="rounded-3xl border border-dashed border-slate-300 bg-white p-14 text-center text-slate-500">No matching orders.</div>}
    </section>
  </AdminShell>
}

